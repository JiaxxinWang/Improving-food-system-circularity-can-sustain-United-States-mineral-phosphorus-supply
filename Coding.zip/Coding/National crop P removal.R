# 加载必要的包
library(readxl)
library(openxlsx)
library(dplyr)

# 清空环境
rm(list = ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 获取所有Excel文件的路径
file_paths <- list.files(path = "P cycling/Crop P removal", pattern = "\\.xlsx$", full.names = TRUE)

# 初始化一个空的数据框来存储合并后的数据
merged_data <- data.frame(YEAR = 1866:2050)

# 循环读取每个Excel文件
for (file_path in file_paths) {
  # 读取当前Excel文件
  current_data <- read_excel(file_path)
  
  # 确保YEAR列存在
  if (!"YEAR" %in% colnames(current_data)) {
    stop(paste("YEAR column not found in", file_path))
  }
  
  # 合并数据
  for (col in colnames(current_data)) {
    if (col == "YEAR") next  # 跳过YEAR列
    
    if (col %in% colnames(merged_data)) {
      # 如果列名已存在，则求和
      merged_data[[col]] <- rowSums(cbind(merged_data[[col]], current_data[[col]]), na.rm = TRUE)
    } else {
      # 如果列名不存在，则添加新列
      merged_data[[col]] <- current_data[[col]]
    }
  }
}

# 计算Corn proportion列
merged_data <- merged_data %>%
  mutate(Corn_proportion = (Corn_grain_P_removal + Corn_silage_P_removal) / Total_P_removal)

# 计算Wheat proportion列
merged_data <- merged_data %>%
  mutate(Wheat_proportion = (Winter_wheat_P_removal + Durum_wheat_P_removal + Spring_wheat_P_removal) / Total_P_removal)

# 计算Soybean proportion列
merged_data <- merged_data %>%
  mutate(Soybean_proportion = Soybeans_P_removal / Total_P_removal)

# 调整列的顺序
merged_data <- merged_data %>%
  select(YEAR, Total_P_removal, Soybean_proportion, Wheat_proportion, Corn_proportion, everything())

# 保存处理后的数据到同一个Excel文件
write.xlsx(merged_data, file = "P cycling/National_crop_P_proportion.xlsx", rowNames = FALSE)

# 打印完成信息
print("处理完成，文件已保存为 'P cycling/National_crop_P_proportion.xlsx'")