# 加载所需的包
library(readxl)
library(dplyr)
library(tidyr)
library(writexl)

# 清空环境
rm(list = ls())

# 设置工作目录为当前文档的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义参数开关
scale_factor <- switch(getOption("global_vars")$monte_carlo_mode,
                         "1" = 0.8,  
                         "2" = 1,    
                         "3" = 1.2)  

average_weight <- list(
  "beef" = 500 * scale_factor,
  "lamb" = 45 * scale_factor,
  "veal" = 220 * scale_factor,
  "pork" = 200 * scale_factor
)
# Daily Uptake of body weight
dry_matter_uptake <- list(
  "beef" = 0.02,
  "lamb" = 0.02,
  "veal" = 0.02
)

p_content_dry_matter <- 0.002   # 0.2%
p_requirement_pork <- 0.006      # 0.6%

# 定义情景
scenarios <- c("Toward Sustainability", "Business As Usual", "Stratified Societies")

# 定义 "red meat loss proportion.xlsx" 中的表
loss_sheets <- c("As usual", "Half")

# 定义文件夹路径
file_folder <- "Initial data/Preprocess/Meat data"
loss_folder <- "Initial data/Preprocess/Food waste"
livestock_folder <- "Initial data/Livestock process"
output_folder <- "P cycling"

# 定义文件名
file_names <- file.path(file_folder, c("beef.xlsx", "lamb&mutton.xlsx", "pork.xlsx", "veal.xlsx", "red_meat_projected.xlsx"))

# 定义肉类类型
meat_types <- c("beef", "lamb&mutton", "pork", "veal", "red_meat_projected")

# 定义红肉损失比例文件名
loss_file <- file.path(loss_folder, "red meat loss proportion.xlsx")

# 定义缺失的州
missing_states <- c("CONNECTICUT", "DELAWARE", "MAINE", "MASSACHUSETTS", "RHODE ISLAND", "VERMONT")

# 定义牲畜类型对应的列名
meat_type_columns <- list(
  beef = c("Beef cows", "Bison", "Bulls", "Heifers beef", "Heifers milk", "Heifers", "Steers"),
  veal = c("Calves", "Milk cows"),
  pork = c("Hog breeding", "Hog slaughter"),
  lamb = c("Sheep lamb", "Goat")
)

# 创建首字母大写的辅助函数
ucfirst <- function(s) {
  paste0(toupper(substr(s, 1, 1)), tolower(substr(s, 2, nchar(s))))
}

# 遍历 "As usual" 和 "Half" 两个损失比例表
for (loss_sheet in loss_sheets) {
  # 添加前缀到文件夹名称
  folder_name <- file.path(output_folder, paste0("Red meat waste - ", loss_sheet))
  
  # 创建当前损失表的文件夹
  dir.create(folder_name, showWarnings = FALSE)
  
  # 创建汇总文件的文件夹
  summary_folder <- file.path(output_folder, paste0("Red meat waste - ", loss_sheet, "_summary"))
  dir.create(summary_folder, showWarnings = FALSE)
  
  # 读取 "red meat loss proportion.xlsx" 中的相应表
  if (file.exists(loss_file)) {
    loss_data <- read_excel(loss_file, sheet = loss_sheet) %>%
      filter(Year >= 1977 & Year <= 2050)
  } else {
    stop("red meat loss proportion.xlsx 文件不存在。")
  }
  
  # 初始化列表以存储每个州每个情景下的 Total_Feed_P_Loss
  state_loss_data <- list()
  
  # 遍历情景
  for (scenario in scenarios) {
    # 初始化列表以存储每种肉类的数据
    data_list <- list()
    
    # 读取每种肉类的数据
    for (i in seq_along(file_names)) {
      file <- file_names[i]
      meat_type <- meat_types[i]
      file_path <- paste0(file)
      
      if (file.exists(file_path)) {
        # 读取当前情景的特定表
        data <- read_excel(file_path, sheet = scenario)
        
        # 选择所需的列并过滤年份（1977-2050）
        if ("State" %in% colnames(data)) {
          filtered_data <- data %>%
            select(Year, State, Value) %>%
            filter(Year >= 1977 & Year <= 2050)
        } else {
          # 对于没有 "State" 列的文件，添加 "US TOTAL" 作为 State
          filtered_data <- data %>%
            mutate(State = "US TOTAL") %>%
            select(Year, State, Value) %>%
            filter(Year >= 1977 & Year <= 2050)
        }
        
        # 将数据存储在列表中
        data_list[[meat_type]] <- filtered_data
      } else {
        warning(paste("文件", file_path, "不存在，已跳过。"))
      }
    }
    
    # 提取红肉数据
    red_meat_data <- data_list[["red_meat_projected"]]
    
    # 检查红肉数据是否可用
    if (is.null(red_meat_data)) {
      stop("红肉数据缺失，请检查文件。")
    }
    
    # 计算每个州的红肉比例
    red_meat_proportion <- red_meat_data %>%
      filter(State != "US TOTAL") %>%
      group_by(Year) %>%
      mutate(proportion = Value / sum(Value, na.rm = TRUE)) %>%
      ungroup()
    
    # 定义计算州生产量的函数
    calculate_state_production <- function(meat_data, red_meat_prop, meat_name) {
      us_total_data <- meat_data %>% filter(State == "US TOTAL")
      
      if (nrow(us_total_data) == 0) {
        stop(paste("缺少", meat_name, "的 US TOTAL 数据。"))
      }
      
      state_production <- red_meat_prop %>%
        left_join(us_total_data, by = c("Year")) %>%
        mutate(State_Production = proportion * Value.y * 0.453592) %>%  # 将磅转换为千克
        select(Year, State.x, State_Production) %>%
        rename(State = State.x)
      return(state_production)
    }
    
    # 计算每种肉类的州级生产量
    beef_production <- calculate_state_production(data_list[["beef"]], red_meat_proportion, "beef")
    lamb_production <- calculate_state_production(data_list[["lamb&mutton"]], red_meat_proportion, "lamb")
    veal_production <- calculate_state_production(data_list[["veal"]], red_meat_proportion, "veal")
    pork_production <- calculate_state_production(data_list[["pork"]], red_meat_proportion, "pork")
    
    # 应用损失比例
    apply_loss_proportion <- function(production_data, loss_data) {
      production_with_loss <- production_data %>%
        left_join(loss_data, by = "Year") %>%
        mutate(Production_with_Loss = State_Production * `Red meat`) %>%
        replace_na(list(Production_with_Loss = 0))
      return(production_with_loss)
    }
    
    # 对每种肉类应用损失比例
    beef_with_loss <- apply_loss_proportion(beef_production, loss_data)
    lamb_with_loss <- apply_loss_proportion(lamb_production, loss_data)
    veal_with_loss <- apply_loss_proportion(veal_production, loss_data)
    pork_with_loss <- apply_loss_proportion(pork_production, loss_data)
    
    # 计算饲料P损失和头损失
    calculate_feed_p_loss <- function(production_data, meat_type) {
      production_data <- production_data %>%
        mutate(Head_Loss = floor(Production_with_Loss / average_weight[[meat_type]]))  # 整数头损失
      
      if (meat_type == "pork") {
        production_data <- production_data %>%
          mutate(Feed_P_Loss = Head_Loss * average_weight[[meat_type]] * p_requirement_pork / 1000)  # 转换为吨
      } else {
        production_data <- production_data %>%
          mutate(Feed_P_Loss = Head_Loss * 365 * average_weight[[meat_type]] * dry_matter_uptake[[meat_type]] * p_content_dry_matter / 1000)  # 转换为吨
      }
      
      return(production_data)
    }
    
    # 计算每种肉类的饲料P损失
    beef_p_loss <- calculate_feed_p_loss(beef_with_loss, "beef")
    lamb_p_loss <- calculate_feed_p_loss(lamb_with_loss, "lamb")
    veal_p_loss <- calculate_feed_p_loss(veal_with_loss, "veal")
    pork_p_loss <- calculate_feed_p_loss(pork_with_loss, "pork")
    
    # 合并所有肉类
    combined_p_loss <- beef_p_loss %>%
      select(Year, State, Beef_Head_Loss = Head_Loss, Beef_Feed_P_Loss = Feed_P_Loss) %>%
      full_join(lamb_p_loss %>% select(Year, State, Lamb_Head_Loss = Head_Loss, Lamb_Feed_P_Loss = Feed_P_Loss), by = c("Year", "State")) %>%
      full_join(veal_p_loss %>% select(Year, State, Veal_Head_Loss = Head_Loss, Veal_Feed_P_Loss = Feed_P_Loss), by = c("Year", "State")) %>%
      full_join(pork_p_loss %>% select(Year, State, Pork_Head_Loss = Head_Loss, Pork_Feed_P_Loss = Feed_P_Loss), by = c("Year", "State"))
    
    combined_p_loss <- combined_p_loss %>%
      mutate(Total_Feed_P_Loss = rowSums(select(., ends_with("Feed_P_Loss")), na.rm = TRUE))
    
    # 计算全国平均头损失比例
    total_head_counts <- list(beef = 0, veal = 0, pork = 0, lamb = 0)
    total_head_loss <- list(beef = 0, veal = 0, pork = 0, lamb = 0)
    
    # 读取44个州的牲畜头数
    for (state in unique(combined_p_loss$State)) {
      # 排除缺失的州
      if (state %in% missing_states) next
      
      # 构建文件路径
      file_path <- file.path(livestock_folder, paste0(state, ".xlsx"))
      
      if (file.exists(file_path)) {
        # 读取Excel文件
        state_data <- read_excel(file_path, sheet = "Sheet1")
        
        # 过滤年份
        state_data <- state_data %>%
          filter(YEAR >= 1977 & YEAR <= 2050)
        
        # 将NA替换为0
        state_data[is.na(state_data)] <- 0
        
        # 计算每种肉类的总头数
        for (meat_type in names(meat_type_columns)) {
          columns_to_sum <- meat_type_columns[[meat_type]]
          existing_columns <- columns_to_sum[columns_to_sum %in% colnames(state_data)]
          
          if (length(existing_columns) > 0) {
            total_heads <- sum(state_data[, existing_columns], na.rm = TRUE)
            total_head_counts[[meat_type]] <- total_head_counts[[meat_type]] + total_heads
          }
        }
      } else {
        warning(paste("文件", file_path, "不存在，已跳过。"))
      }
    }
    
    # 从之前的计算中获取总头损失
    for (meat_type in names(total_head_loss)) {
      head_loss_column <- paste0(ucfirst(meat_type), "_Head_Loss")
      total_head_loss[[meat_type]] <- sum(combined_p_loss[[head_loss_column]], na.rm = TRUE)
    }
    
    # 计算全国平均头损失比例
    head_loss_proportion <- list()
    for (meat_type in names(total_head_counts)) {
      total_heads <- total_head_counts[[meat_type]]
      total_losses <- total_head_loss[[meat_type]]
      
      if (total_heads > 0) {
        head_loss_proportion[[meat_type]] <- total_losses / total_heads
      } else {
        head_loss_proportion[[meat_type]] <- 0
      }
    }
    
    # 估算缺失州的数据
    missing_states_p_loss_list <- list()
    
    for (state in missing_states) {
      # 构建文件路径
      file_path <- file.path(livestock_folder, paste0(state, ".xlsx"))
      
      if (file.exists(file_path)) {
        # 读取Excel文件
        state_data <- read_excel(file_path, sheet = "Sheet1")
        
        # 过滤年份
        state_data <- state_data %>%
          filter(YEAR >= 1977 & YEAR <= 2050)
        
        # 将NA替换为0
        state_data[is.na(state_data)] <- 0
        
        # 初始化数据框以存储结果
        state_p_loss <- data.frame(
          Year = state_data$YEAR,
          State = state,
          Beef_Head_Loss = 0,
          Lamb_Head_Loss = 0,
          Veal_Head_Loss = 0,
          Pork_Head_Loss = 0,
          Beef_Feed_P_Loss = 0,
          Lamb_Feed_P_Loss = 0,
          Veal_Feed_P_Loss = 0,
          Pork_Feed_P_Loss = 0,
          Total_Feed_P_Loss = 0
        )
        
        # 计算每种肉类的头损失和饲料P损失
        for (meat_type in names(meat_type_columns)) {
          columns_to_sum <- meat_type_columns[[meat_type]]
          existing_columns <- columns_to_sum[columns_to_sum %in% colnames(state_data)]
          
          if (length(existing_columns) > 0) {
            total_head_counts_yearly <- rowSums(state_data[, existing_columns], na.rm = TRUE)
            hlp <- head_loss_proportion[[meat_type]]
            estimated_head_loss <- floor(total_head_counts_yearly * hlp)
            state_p_loss[[paste0(ucfirst(meat_type), "_Head_Loss")]] <- estimated_head_loss
            
            if (meat_type == "pork") {
              feed_P_Loss <- estimated_head_loss * average_weight[[meat_type]] * p_requirement_pork / 1000  # 吨
            } else {
              feed_P_Loss <- estimated_head_loss * 365 * average_weight[[meat_type]] * dry_matter_uptake[[meat_type]] * p_content_dry_matter / 1000
            }
            
            state_p_loss[[paste0(ucfirst(meat_type), "_Feed_P_Loss")]] <- feed_P_Loss
          }
        }
        
        # 计算总饲料P损失
        state_p_loss$Total_Feed_P_Loss <- rowSums(state_p_loss[, grep("Feed_P_Loss$", names(state_p_loss))], na.rm = TRUE)
        
        # 添加到列表
        missing_states_p_loss_list[[state]] <- state_p_loss
      } else {
        warning(paste("文件", file_path, "不存在，已跳过。"))
      }
    }
    
    # 合并缺失州的数据
    missing_states_p_loss <- bind_rows(missing_states_p_loss_list)
    
    # 合并所有州的数据
    existing_states_p_loss <- combined_p_loss %>%
      select(Year, State,
             Beef_Head_Loss, Lamb_Head_Loss, Veal_Head_Loss, Pork_Head_Loss,
             Beef_Feed_P_Loss, Lamb_Feed_P_Loss, Veal_Feed_P_Loss, Pork_Feed_P_Loss,
             Total_Feed_P_Loss)
    
    all_states_p_loss <- bind_rows(existing_states_p_loss, missing_states_p_loss)
    
    # 为每个州保存结果
    for (state in unique(all_states_p_loss$State)) {
      state_data <- all_states_p_loss %>%
        filter(State == state)
      
      # 创建情景的文件夹
      scenario_folder <- file.path(folder_name, scenario)
      dir.create(scenario_folder, showWarnings = FALSE, recursive = TRUE)
      
      # 构建文件路径
      file_path <- file.path(scenario_folder, paste0(state, ".xlsx"))
      
      # 将数据写入Excel文件
      write_xlsx(state_data, file_path)
      
      ### 新增代码开始 ###
      # 为汇总文件存储 Total_Feed_P_Loss
      if (!state %in% names(state_loss_data)) {
        # 初始化州的数据框
        state_loss_data[[state]] <- data.frame(Year = state_data$Year)
      }
      # 添加当前情景的 Total_Feed_P_Loss
      state_loss_data[[state]][[scenario]] <- state_data$Total_Feed_P_Loss
      ### 新增代码结束 ###
    }
  }
  
  ### 新增代码开始 ###
  # 在处理完所有情景后，保存汇总文件
  for (state in names(state_loss_data)) {
    state_summary_data <- state_loss_data[[state]]
    
    # 确保列的顺序正确
    state_summary_data <- state_summary_data %>%
      select(Year, `Toward Sustainability`, `Business As Usual`, `Stratified Societies`)
    
    # 重命名情景列以添加前缀 "TotalfeedP_loss_"
    colnames(state_summary_data)[2:4] <- paste0("TotalfeedP_loss_", colnames(state_summary_data)[2:4])
    
    # 构建文件路径
    file_path <- file.path(summary_folder, paste0(state, ".xlsx"))
    
    # 将数据写入Excel文件
    write_xlsx(state_summary_data, file_path)
  }
  ### 新增代码结束 ###
  
  print(paste("所有关于损失表", loss_sheet, "的文件已成功生成并保存到", folder_name, "和", summary_folder, "中！"))
}
