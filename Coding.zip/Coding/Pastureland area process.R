# Load necessary libraries
library(readxl)
library(openxlsx)
library(dplyr)
library(rstudioapi)

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Read the "after process" sheet
file_path <- "Preprocess/Pasture area/Pastureland area.xlsx"
data <- read_excel(file_path, sheet = "after process")

# Extract unique states
states <- unique(data$State)

# 创建保存新文件的文件夹
output_dir <- "Pastureland area"
if (!dir.exists(output_dir)) {
  dir.create(output_dir)
}

# Function to convert acres to hectares and keep integer part
acres_to_hectares <- function(acres) {
  return(floor(acres * 0.404686))
}

# Iterate through each state and process the data
for (state in states) {
  # Filter data for the current state
  state_data <- data %>% filter(State == state)
  
  # 将Value列转换为数值类型，并将NA转换为0
  state_data <- state_data %>% mutate(Value = as.numeric(Value))
  state_data$Value[is.na(state_data$Value)] <- 0
  
  # Step 1: Sum values for Year 2013 and rename Value to Total_Area
  sum_2013 <- state_data %>% 
    filter(Year == 2013) %>% 
    group_by(Year) %>% 
    summarise(Total_Area = sum(Value, na.rm = TRUE))
  
  # Step 2: Calculate the value for Year 2018
  irrigated_2018 <- state_data %>% 
    filter(Year == 2018, `Data Item` == "PASTURELAND, IRRIGATED - ACRES") %>% 
    summarise(Value = sum(Value, na.rm = TRUE)) %>% 
    pull()
  
  irrigated_2013 <- state_data %>% 
    filter(Year == 2013, `Data Item` == "PASTURELAND, IRRIGATED - ACRES") %>% 
    summarise(Value = sum(Value, na.rm = TRUE)) %>% 
    pull()
  
  non_irrigated_2013 <- state_data %>% 
    filter(Year == 2013, `Data Item` == "PASTURELAND, NON-IRRIGATED - ACRES") %>% 
    summarise(Value = sum(Value, na.rm = TRUE)) %>% 
    pull()
  
  value_2018 <- irrigated_2018 - irrigated_2013 + non_irrigated_2013
  
  # Create new row for Year 2018
  new_row_2018 <- data.frame(
    YEAR = 2018,
    Total_Area = value_2018
  )
  
  # Combine the new rows
  sum_2013 <- sum_2013 %>% rename(YEAR = Year)
  new_state_data <- bind_rows(sum_2013, new_row_2018)
  
  # Initialize the dataframe for expanded data from 1866 to 2050
  expanded_data <- data.frame(YEAR = 1866:2050, Total_Area = NA)
  
  # Fill the data from 2010 to 2013 with 2013 values
  expanded_data$Total_Area[expanded_data$YEAR >= 2010 & expanded_data$YEAR <= 2013] <- sum_2013$Total_Area
  
  # Fill the data from 2014 to 2017 with linear interpolation
  for (year in 2014:2017) {
    expanded_data$Total_Area[expanded_data$YEAR == year] <- round(
      sum_2013$Total_Area + (year - 2013) * (value_2018 - sum_2013$Total_Area) / (2018 - 2013)
    )
  }
  
  # Fill the data from 2018 to 2022 with 2018 values
  expanded_data$Total_Area[expanded_data$YEAR >= 2018 & expanded_data$YEAR <= 2022] <- value_2018
  
  # Calculate the average value for 2013 and 2018
  avg_value <- (sum_2013$Total_Area + value_2018) / 2
  
  # Fill the data from 2023 to 2050 with the average value
  expanded_data$Total_Area[expanded_data$YEAR >= 2023 & expanded_data$YEAR <= 2050] <- avg_value
  expanded_data$Total_Area[expanded_data$YEAR >= 1866 & expanded_data$YEAR <= 2009] <- avg_value
  # Convert acres to hectares and keep integer part
  expanded_data$Total_Area <- acres_to_hectares(expanded_data$Total_Area)
  
  # Create a new Excel file for the state
  new_file_path <- file.path(output_dir, paste0(state, ".xlsx"))
  write.xlsx(expanded_data, new_file_path)
  
  print(paste("File created for state:", state))
}

print("Processing complete.")
