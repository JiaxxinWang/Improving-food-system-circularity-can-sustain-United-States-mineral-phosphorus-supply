
###########################################################################################
############################ Egg shell P production with Monte Carlo ######################
###########################################################################################

# 加载所需的包
library(dplyr)
library(readxl)
library(openxlsx)

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义文件路径
input_folder <- "Initial data/Preprocess/Egg_production/HI"  # 原始文件路径
output_folder <- "P cycling/Egg shell P production"      # 保存处理后文件的路径

# 检查输出文件夹是否存在，不存在则创建
if (!dir.exists(output_folder)) {
  dir.create(output_folder, recursive = TRUE)
}

# 定义鸡蛋参数范围（蒙特卡洛）
egg_shell_weight_range <- c(5 / 1000000, 7 / 1000000)  # 鸡蛋壳重量范围 5g到7g (单位: 吨)
egg_shell_P_range <- c(0.28 / 100, 0.32 / 100)         # 磷浓度范围 0.28% 到 0.32%

# Monte Carlo mode (1: 5th percentile, 2: mean, 3: 95th percentile)
# monte_carlo_mode <- 2

# 根据开关选择不同的百分位数函数
get_percentile_value <- function(range, mode_value) {
  if (mode_value == 1) {
    return(quantile(runif(10000, range[1], range[2]), probs = 0.05))
  } else if (mode_value == 2) {
    return(mean(range))
  } else if (mode_value == 3) {
    return(quantile(runif(10000, range[1], range[2]), probs = 0.95))
  } else {
    stop("Invalid Monte Carlo mode value. Choose 1, 2, or 3.")
  }
}

# 根据mode取对应的参数值
egg_shell_weight <- get_percentile_value(egg_shell_weight_range, getOption("global_vars")$monte_carlo_mode)
egg_shell_P <- get_percentile_value(egg_shell_P_range, getOption("global_vars")$monte_carlo_mode)

# 打印选择的参数值以供检查
cat("Selected Egg Shell Weight (ton/egg):", egg_shell_weight, "\n")
cat("Selected Egg Shell P Concentration (%):", egg_shell_P, "\n")

# 读取所有Excel文件，并进行计算和保存
file_list <- list.files(path = input_folder, pattern = "*.xlsx", full.names = TRUE)

for (file in file_list) {
  # 读取每个Excel文件的第一个工作表
  data <- read_excel(file)
  
  # 确保数据包含“YEAR”和“Egg_production”列
  if (!all(c("YEAR", "Egg_production") %in% colnames(data))) {
    cat("Warning: Missing 'YEAR' or 'Egg_production' column in file:", basename(file), "\n")
    next
  }
  
  # 计算Eggshell_P = Egg_production * egg_shell_weight * egg_shell_P
  data <- data %>%
    mutate(Eggshell_P = Egg_production * egg_shell_weight * egg_shell_P) %>%
    select(YEAR, Eggshell_P)  # 保留YEAR和新计算的Eggshell_P列
  
  # 生成新的文件名
  output_file_name <- paste0(output_folder, "/", basename(file))
  
  # 保存到新的Excel文件
  write.xlsx(data, output_file_name, rowNames = FALSE)
  cat("Processed and saved file:", output_file_name, "\n")
}

cat("All files processed and saved successfully.\n")
