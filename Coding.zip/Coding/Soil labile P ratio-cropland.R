# 加载必要的库
library(readxl)
library(openxlsx)
library(dplyr)

# 清空环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 读取“州历史数据和1866-2023.xlsx”
state_data <- read_xlsx("P cycling/州历史数据和1866-2023.xlsx")

# 获取State列
states <- state_data$State

# 初始化结果列表
results <- data.frame()

# 遍历每个州，读取对应的文件并提取所需数据
for (state in states) {
  # 读取同名 Excel 文件
  state_file <- paste0("P cycling/DPPS cropland/", state, ".xlsx")
  if (file.exists(state_file)) {
    state_excel <- read_xlsx(state_file)
    
    # 提取2023年的数据
    state_2023_data <- state_excel %>%
      filter(YEAR == 2023) %>%
      select(`Final soil labile P pool`, `Final soil P pool`)
    
    # 获取“Mineral P application”列数据
    mineral_p_application <- state_data %>%
      filter(State == state) %>%
      pull(`Mineral P application`)
    
    # 合并结果
    state_result <- data.frame(
      State = state,
      `Final soil labile P pool` = state_2023_data$`Final soil labile P pool`,
      `Final soil P pool` = state_2023_data$`Final soil P pool`,
      `Mineral P application` = mineral_p_application
    )
    results <- rbind(results, state_result)
  }
}

# 确保列名保持原样
colnames(results) <- c("State", "Final soil labile P pool", "Final soil P pool", "Mineral P application")

# 将结果写入 Excel 文件
write.xlsx(results, "P cycling/Cropland-ratio-2023.xlsx", check.names = FALSE)








# 加载必要的库
library(readxl)
library(openxlsx)
library(dplyr)

# 清空环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 读取“州历史数据和2024-2050.xlsx”
state_data <- read_xlsx("P cycling/州历史数据和2024-2050.xlsx")

# 获取State列
states <- state_data$State

# 初始化结果列表
results <- data.frame()

# 遍历每个州，读取对应的文件并提取所需数据
for (state in states) {
  # 读取同名 Excel 文件
  state_file <- paste0("P cycling/DPPS cropland/", state, ".xlsx")
  if (file.exists(state_file)) {
    state_excel <- read_xlsx(state_file)
    
    # 提取2050年的数据
    state_2050_data <- state_excel %>%
      filter(YEAR == 2050) %>%
      select(`Final soil labile P pool`, `Final soil P pool`)
    
    # 获取“Mineral P application”列数据
    mineral_p_application <- state_data %>%
      filter(State == state) %>%
      pull(`Mineral P application`)
    
    # 合并结果
    state_result <- data.frame(
      State = state,
      `Final soil labile P pool` = state_2050_data$`Final soil labile P pool`,
      `Final soil P pool` = state_2050_data$`Final soil P pool`,
      `Mineral P application` = mineral_p_application
    )
    results <- rbind(results, state_result)
  }
}

# 确保列名保持原样
colnames(results) <- c("State", "Final soil labile P pool", "Final soil P pool", "Mineral P application")

# 将结果写入 Excel 文件
write.xlsx(results, "P cycling/Cropland-ratio-2050.xlsx", check.names = FALSE)