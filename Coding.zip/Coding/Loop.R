# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Loading process scripts
source("Crop area.R")
source("Crop production.R")
source("Livestock slaughter head.R")
source("Livestock slaughter process.R")
source("Livestock process.R")
source("Pastureland area process.R")
source("Population process.R")
source("PRCP process.R")
source("Runoff loss coefficient.R")

print('所有R代码数据已经处理完成')
