# 加载必要的库
library(readxl)
library(openxlsx)
library(dplyr)
library(rstudioapi)

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义Excel文件的路径
file_path <- "Preprocess/Population/Population.xlsx"

# 读取Excel文件的数据
data <- read_excel(file_path, sheet="HI") # HI; #Zero

# 获取所有独特的州名
states <- unique(data$LOCATION)

# 定义文件路径的目录
file_direction <- "Population process"

# 检查并创建目录（如果不存在）
if (!dir.exists(file_direction)) {
  dir.create(file_direction, recursive = TRUE)
}

# 创建一个循环，通过州名过滤数据并保存到单独的Excel文件中
for (state in states) {
  # 过滤出当前州的数据
  state_data <- data %>%
    filter(LOCATION == state) %>%
    select(YEAR, Population)
  
  # 定义文件路径和文件名
  file_name <- paste0(file_direction, "/", state, ".xlsx")
  
  # 将数据保存为Excel文件
  write.xlsx(state_data, file = file_name, rowNames = FALSE)
}

print("数据已成功写入各个州的单独文件。")

# 定义要移动特定文件的目标目录
target_dir <- "剔除excel/Population process"
dir.create(target_dir, recursive = TRUE, showWarnings = FALSE)

# 移动 "DISTRICT OF COLUMBIA.xlsx" 文件
file.rename(file.path(file_direction, "DISTRICT OF COLUMBIA.xlsx"), file.path(target_dir, "DISTRICT OF COLUMBIA.xlsx"))

print("DISTRICT OF COLUMBIA.xlsx 已被移动到目标目录。")
