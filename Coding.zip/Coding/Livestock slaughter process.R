# Load required libraries
library(readxl)
library(writexl)
library(dplyr)

# Clear environment
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 设置包含畜牧业数据文件的目录
livestock_files_dir <- "Livestock slaughter head"

# 列出目录中的所有Excel文件
livestock_files <- list.files(livestock_files_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 初始化一个列表来保存每个州的数据
state_data <- list()

# 定义全年的范围
years <- data.frame(YEAR = 1866:2050)

# 处理每个畜牧业文件
for (livestock_file in livestock_files) {
  # 从文件名中提取畜牧业名称
  livestock_name <- gsub(".xlsx", "", basename(livestock_file))
  
  # 读取Excel文件的数据
  df <- read_excel(livestock_file)
  
  # 提取必要的列并重命名生产列
  df <- df %>% select(YEAR, LOCATION, `Head`) %>% rename(!!livestock_name := `Head`)
  
  # 按州分组数据
  for (state in unique(df$LOCATION)) {
    state_df <- df %>% filter(LOCATION == state) %>% select(YEAR, !!livestock_name)
    state_df <- full_join(years, state_df, by = "YEAR") %>% arrange(YEAR)
    if (!state %in% names(state_data)) {
      state_data[[state]] <- state_df
    } else {
      result <- tryCatch({
        state_data[[state]] <- full_join(state_data[[state]], state_df, by = "YEAR") %>% arrange(YEAR)
        TRUE
      }, warning = function(w) {
        if (grepl("many-to-many relationship", w$message)) {
          cat("Warning in file:", livestock_file, "for state:", state, "\n")
          print(w$message)
          FALSE
        }
      })
      if (!result) {
        stop("Paused due to many-to-many relationship warning.")
      }
    }
  }
}

# 创建一个输出目录来保存州文件
output_dir <- "Livestock slaughter process"
dir.create(output_dir, showWarnings = FALSE)

# 保存每个州的数据到单独的Excel文件
for (state in names(state_data)) {
  # 确保YEAR列从1866到2050是完整的
  state_df <- full_join(years, state_data[[state]], by = "YEAR") %>% arrange(YEAR)
  output_file_path <- file.path(output_dir, paste0(state, ".xlsx"))
  write_xlsx(state_df, output_file_path)
}

print("Data extraction and saving completed.")

# 定义要移动特定文件的目标目录
target_dir <- "剔除excel/Livestock slaughter process"
dir.create(target_dir, recursive = TRUE, showWarnings = FALSE)

# 移动"OTHER STATES.xlsx"和"NEW ENGLAND.xlsx"文件
file.rename(file.path(output_dir, "OTHER STATES.xlsx"), file.path(target_dir, "OTHER STATES.xlsx"))
file.rename(file.path(output_dir, "NEW ENGLAND.xlsx"), file.path(target_dir, "NEW ENGLAND.xlsx"))

print("OTHER STATES.xlsx and NEW ENGLAND.xlsx have been moved to the target directory.")
