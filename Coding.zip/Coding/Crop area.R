# Load required libraries
library(readxl)
library(writexl)
library(dplyr)

# Clear environment
rm(list=ls())

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Set the directory containing the crop data files
crop_files_dir <- "Preprocess/Crop"

# List of all crop files in the directory
crop_files <- list.files(crop_files_dir, pattern = "\\.xlsx$", full.names = TRUE)

# Initialize a list to hold data for each state
state_data <- list()

# Define the full range of years
years <- data.frame(YEAR = 1866:2050)

# Process each crop file
for (crop_file in crop_files) {
  # Extract the crop name from the file name
  crop_name <- gsub(".xlsx", "", basename(crop_file))
  
  # Read the data from the Excel file
  df <- read_excel(crop_file, sheet = "Sheet 1")
  
  # Extract the necessary columns and rename the production column
  df <- df %>% select(YEAR, LOCATION, `AREA PLANTED in HECTARES`) %>% rename(!!crop_name := `AREA PLANTED in HECTARES`)
  
  # Group data by state
  for (state in unique(df$LOCATION)) {
    state_df <- df %>% filter(LOCATION == state) %>% select(YEAR, !!crop_name)
    state_df <- full_join(years, state_df, by = "YEAR") %>% arrange(YEAR)
    if (!state %in% names(state_data)) {
      state_data[[state]] <- state_df
    } else {
      state_data[[state]] <- full_join(state_data[[state]], state_df, by = "YEAR") %>% arrange(YEAR)
    }
  }
}

# Create an output directory for the state files
output_dir <- "Crop area"
dir.create(output_dir, showWarnings = FALSE)

# Initialize a data frame to hold the sum for the entire US
us_sum <- data.frame(YEAR = 1866:2050)

# Calculate the sum of production for each state and save to a separate Excel file
for (state in names(state_data)) {
  # Ensure the YEAR column is complete from 1866 to 2050
  state_df <- full_join(years, state_data[[state]], by = "YEAR") %>% arrange(YEAR)
  # Calculate the sum of production for each year
  state_sum <- state_df %>% rowwise() %>% mutate(Total_Area = sum(c_across(-YEAR), na.rm = TRUE)) %>% ungroup()
  # Add the state's sum to the US sum
  us_sum <- full_join(us_sum, state_sum, by = "YEAR") %>% mutate(Total_Area = rowSums(select(., starts_with("Total_Area")), na.rm = TRUE)) %>% select(YEAR, everything())
  # Save the state's data (including individual crop areas) to a separate Excel file
  output_file_path <- file.path(output_dir, paste0(state, ".xlsx"))
  write_xlsx(state_sum, output_file_path)
}

# Save the US sum to a separate Excel file
us_output_file_path <- file.path(output_dir, "US Total Area.xlsx")
write_xlsx(us_sum, us_output_file_path)

print("Data extraction, summing, and saving completed.")

# Define the target directory for moving specific files
target_dir <- "剔除excel/Crop area"
dir.create(target_dir, recursive = TRUE, showWarnings = FALSE)

# Move the "OTHER STATES.xlsx" and "US Total Area.xlsx" files
file.rename(file.path(output_dir, "OTHER STATES.xlsx"), file.path(target_dir, "OTHER STATES.xlsx"))
file.rename(file.path(output_dir, "US Total Area.xlsx"), file.path(target_dir, "US Total Area.xlsx"))

print("Files have been moved to the target directory.")
