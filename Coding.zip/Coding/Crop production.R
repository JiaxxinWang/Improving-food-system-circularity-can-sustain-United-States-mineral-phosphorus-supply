# Load required libraries
library(readxl)
library(writexl)
library(dplyr)

# Clear environment
rm(list=ls())

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Set the directory containing the crop data files
crop_files_dir <- "Preprocess/Crop"

# List of all crop files in the directory
crop_files <- list.files(crop_files_dir, pattern = "\\.xlsx$", full.names = TRUE)

# Initialize a list to hold data for each state
state_data <- list()

# Define the full range of years
years <- data.frame(YEAR = 1866:2050)

# Process each crop file
for (crop_file in crop_files) {
  # Extract the crop name from the file name
  crop_name <- gsub(".xlsx", "", basename(crop_file))
  
  # Read the data from the Excel file
  df <- read_excel(crop_file, sheet = "Sheet 1")
  
  # Extract the necessary columns and rename the production column
  df <- df %>% select(YEAR, LOCATION, `PRODUCTION in TON`) %>% rename(!!crop_name := `PRODUCTION in TON`)
  
  # Group data by state
  for (state in unique(df$LOCATION)) {
    state_df <- df %>% filter(LOCATION == state) %>% select(YEAR, !!crop_name)
    state_df <- full_join(years, state_df, by = "YEAR") %>% arrange(YEAR)
    if (!state %in% names(state_data)) {
      state_data[[state]] <- state_df
    } else {
      state_data[[state]] <- full_join(state_data[[state]], state_df, by = "YEAR") %>% arrange(YEAR)
    }
  }
}

# Create an output directory for the state files
output_dir <- "Crop production"
dir.create(output_dir, showWarnings = FALSE)

# Save each state's data to a separate Excel file
for (state in names(state_data)) {
  # Ensure the YEAR column is complete from 1866 to 2050
  state_df <- full_join(years, state_data[[state]], by = "YEAR") %>% arrange(YEAR)
  output_file_path <- file.path(output_dir, paste0(state, ".xlsx"))
  write_xlsx(state_df, output_file_path)
}

print("Data extraction and saving completed.")

# Define the target directory for moving the specific file
target_dir <- "剔除excel/Crop production"
dir.create(target_dir, recursive = TRUE, showWarnings = FALSE)

# Move the "OTHER STATES.xlsx" file
file.rename(file.path(output_dir, "OTHER STATES.xlsx"), file.path(target_dir, "OTHER STATES.xlsx"))

print("OTHER STATES.xlsx has been moved to the target directory.")
