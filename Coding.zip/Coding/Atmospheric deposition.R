# 加载必要的库
library(readxl)
library(openxlsx)
library(dplyr)
library(rstudioapi)

################################################################################################
################################# Atmospheric deposition - cropland ############################
################################################################################################

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义输入和输出文件夹路径
input_dir <- "Initial data/Crop area"
output_dir <- "P cycling/Atmospheric deposition - cropland"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 列出输入目录中的所有Excel文件
crop_files <- list.files(input_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 初始化一个列表来存储警告信息
warnings_list <- list()

# 定义不同州的Atmospheric_Deposition系数
atmospheric_deposition_coefficients <- list(
  "ILLINOIS" = 1.1,
  "NEW HAMPSHIRE" = 0.075,
  "MICHIGAN" = 0.2025,
  "NORTH CAROLINA" = 0.34,
  "IOWA" = 0.3,
  "PENNSYLVANIA" = 1.13,
  "NEVADA" = 0.33,
  "TENNESSEE" = 0.54,
  "OKLAHOMA" = 0.61,
  "WEST VIRGINIA" = 0.31,
  "OHIO" = 0.1,
  "COLORADO" = 0.1,
  "VERMONT" = 0.16,
  "NEW YORK" = 0.16,
  "MINNESOTA" = 0.205,
  "MARYLAND" = 0.6,
  "RHODE ISLAND" = 0.07,
  "FLORIDA" = 0.455,
  "CONNECTICUT" = 0.0475,
  "VIRGINIA" = 0.64,
  "CALIFORNIA" = 0.25,
  "UTAH" = 1
)

# 处理每个Excel文件
for (crop_file in crop_files) {
  # 尝试捕获每个循环中的警告信息
  warning_state <- tryCatch({
    # 读取Excel文件
    data <- read_excel(crop_file)
    
    # 获取文件名（不包含扩展名）
    file_name <- tools::file_path_sans_ext(basename(crop_file))
    
    # 获取对应的Atmospheric_Deposition系数，如果没有则使用默认值0.4
    atmospheric_deposition_coefficient <- atmospheric_deposition_coefficients[[file_name]]
    if (is.null(atmospheric_deposition_coefficient)) {
      atmospheric_deposition_coefficient <- 0.4
    }
    
    # 选择"YEAR"列和处理后的"Atmospheric_Deposition"列
    processed_data <- data %>%
      select(YEAR, Total_Area) %>%
      mutate(Atmospheric_Deposition = Total_Area * atmospheric_deposition_coefficient / 1000) %>%
      select(YEAR, Atmospheric_Deposition)
    
    # 定义输出文件路径
    output_file_path <- file.path(output_dir, paste0(file_name, ".xlsx"))
    
    # 将处理后的数据保存为新的Excel文件
    write.xlsx(processed_data, file = output_file_path, rowNames = FALSE)
    
    NULL  # 如果没有警告，返回NULL
  }, warning = function(w) {
    # 如果有警告，将其添加到警告列表中
    return(w)
  })
  
  # 将当前文件的警告信息添加到警告列表中
  if (!is.null(warning_state)) {
    warnings_list[[crop_file]] <- warning_state
  }
}

# 打印所有的警告信息
if (length(warnings_list) > 0) {
  print("警告信息：")
  print(warnings_list)
} else {
  print("没有警告信息。")
}

print("数据已成功写入新的文件夹。")


################################################################################################
################################ Atmospheric deposition - pastureland ##########################
################################################################################################

# 清空环境
rm(list=ls())

# 定义输入和输出文件夹路径
input_dir <- "Initial data/Pastureland area"
output_dir <- "P cycling/Atmospheric deposition - pastureland"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 列出输入目录中的所有Excel文件
crop_files <- list.files(input_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 初始化一个列表来存储警告信息
warnings_list <- list()

# 定义不同州的Atmospheric_Deposition系数
atmospheric_deposition_coefficients <- list(
  "ILLINOIS" = 1.1,
  "NEW HAMPSHIRE" = 0.075,
  "MICHIGAN" = 0.2025,
  "NORTH CAROLINA" = 0.34,
  "IOWA" = 0.3,
  "PENNSYLVANIA" = 1.13,
  "NEVADA" = 0.33,
  "TENNESSEE" = 0.54,
  "OKLAHOMA" = 0.61,
  "WEST VIRGINIA" = 0.31,
  "OHIO" = 0.1,
  "COLORADO" = 0.1,
  "VERMONT" = 0.16,
  "NEW YORK" = 0.16,
  "MINNESOTA" = 0.205,
  "MARYLAND" = 0.6,
  "RHODE ISLAND" = 0.07,
  "FLORIDA" = 0.455,
  "CONNECTICUT" = 0.0475,
  "VIRGINIA" = 0.64,
  "CALIFORNIA" = 0.25,
  "UTAH" = 1
)

# 处理每个Excel文件
for (crop_file in crop_files) {
  # 尝试捕获每个循环中的警告信息
  warning_state <- tryCatch({
    # 读取Excel文件
    data <- read_excel(crop_file)
    
    # 获取文件名（不包含扩展名）
    file_name <- tools::file_path_sans_ext(basename(crop_file))
    
    # 获取对应的Atmospheric_Deposition系数，如果没有则使用默认值0.4
    atmospheric_deposition_coefficient <- atmospheric_deposition_coefficients[[file_name]]
    if (is.null(atmospheric_deposition_coefficient)) {
      atmospheric_deposition_coefficient <- 0.4
    }
    
    # 选择"YEAR"列和处理后的"Atmospheric_Deposition"列
    processed_data <- data %>%
      select(YEAR, Total_Area) %>%
      mutate(Atmospheric_Deposition = Total_Area * atmospheric_deposition_coefficient / 1000) %>%
      select(YEAR, Atmospheric_Deposition)
    
    # 定义输出文件路径
    output_file_path <- file.path(output_dir, paste0(file_name, ".xlsx"))
    
    # 将处理后的数据保存为新的Excel文件
    write.xlsx(processed_data, file = output_file_path, rowNames = FALSE)
    
    NULL  # 如果没有警告，返回NULL
  }, warning = function(w) {
    # 如果有警告，将其添加到警告列表中
    return(w)
  })
  
  # 将当前文件的警告信息添加到警告列表中
  if (!is.null(warning_state)) {
    warnings_list[[crop_file]] <- warning_state
  }
}

# 打印所有的警告信息
if (length(warnings_list) > 0) {
  print("警告信息：")
  print(warnings_list)
} else {
  print("没有警告信息。")
}

print("数据已成功写入新的文件夹。")
