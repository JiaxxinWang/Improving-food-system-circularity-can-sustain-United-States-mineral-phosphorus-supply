# 加载必要的库
library(readxl)
library(writexl)
library(dplyr)

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

#########################################################################################
################################## Crop yield P removal #################################
#########################################################################################

######### Crop P content with Monte Carlo #########

# 定义 coefficients pool 为区间（最小值和最大值）
coefficients_pool <- list(
  Barley = c(0.32/100, 0.40/100),    # 0.36 +/- 10%
  Beans = c(0.42/100, 0.52/100),     # 0.47 +/- 10%
  Canola = c(0.41/100, 0.49/100),    # 0.45 +/- 10%
  Corn_grain = c(0.27/100, 0.33/100),# 0.30 +/- 10%
  Corn_silage = c(0.16/100, 0.20/100),# 0.18 +/- 10%
  Cotton = c(0.38/100, 0.46/100),    # 0.42 +/- 10%
  Flaxseed = c(0.51/100, 0.63/100),  # 0.57 +/- 10%
  Hay = c(0.22/100, 0.26/100),       # 0.24 +/- 10%
  Haylage = c(0.22/100, 0.26/100),   # 0.24 +/- 10%
  Hops = c(0.14/100, 0.17/100),      # 0.15 +/- 10%
  Lentils = c(0.37/100, 0.45/100),   # 0.41 +/- 10%
  Millet = c(0.32/100, 0.39/100),    # 0.35 +/- 10%
  Mustard = c(0.42/100, 0.52/100),   # 0.47 +/- 10%
  Oats = c(0.34/100, 0.42/100),      # 0.38 +/- 10%
  Peanuts = c(0.22/100, 0.26/100),   # 0.24 +/- 10%
  Peas = c(0.34/100, 0.42/100),      # 0.38 +/- 10%
  Rapeseed = c(0.63/100, 0.77/100),  # 0.70 +/- 10%
  Rice = c(0.26/100, 0.32/100),      # 0.29 +/- 10%
  Rye = c(0.32/100, 0.40/100),       # 0.36 +/- 10%
  Safflower = c(0.05/100, 0.07/100), # 0.06 +/- 10%
  Sorghum_grain = c(0.31/100, 0.37/100),# 0.34 +/- 10%
  Sorghum_silage = c(0.19/100, 0.23/100),# 0.21 +/- 10%
  Soybeans = c(0.47/100, 0.57/100),  # 0.52 +/- 10%
  Sugarbeets = c(0.045/100, 0.055/100), # 0.05 +/- 10%
  Sugarcane = c(0.027/100, 0.033/100), # 0.03 +/- 10%
  Sunflower = c(0.39/100, 0.47/100), # 0.43 +/- 10%
  Taro = c(0.063/100, 0.077/100),    # 0.07 +/- 10%
  Tobacco = c(0.36/100, 0.44/100),   # 0.40 +/- 10%
  Spring_wheat = c(0.27/100, 0.33/100),# 0.30 +/- 10%
  Winter_wheat = c(0.27/100, 0.33/100),# 0.30 +/- 10%
  Durum_wheat = c(0.27/100, 0.33/100),# 0.30 +/- 10%
  Coffee = c(0.14/100, 0.18/100),    # 0.16 +/- 10%
  Potatoes = c(0.063/100, 0.077/100),# 0.07 +/- 10%
  Sweet_corn = c(0.25/100, 0.31/100),# 0.28 +/- 10%
  Vegetable_sum = c(0.036/100, 0.044/100),# 0.04 +/- 10%
  Nut_sum = c(0.37/100, 0.45/100),   # 0.41 +/- 10%
  Fruit_sum = c(0.018/100, 0.022/100) # 0.02 +/- 10%
)

# 设置包含 Excel 数据文件的目录
excel_files_dir <- "Initial data/Crop production" # 替换为实际的目录

# 设置输出文件夹
output_folder <- "P cycling/Crop P removal"

# 创建输出文件夹（递归创建）
if (!dir.exists(output_folder)) {
  dir.create(output_folder, recursive = TRUE)
}

# 设置开关，控制蒙特卡洛模拟模式
get_coefficient <- function(coefficient_range, mode) {
  if (mode == 1) {
    # 5% 分位数
    return(coefficient_range[1] + 0.05 * (coefficient_range[2] - coefficient_range[1]))
  } else if (mode == 2) {
    # 均值
    return(mean(coefficient_range))
  } else if (mode == 3) {
    # 95% 分位数
    return(coefficient_range[1] + 0.95 * (coefficient_range[2] - coefficient_range[1]))
  }
}

# 列出目录中的所有 Excel 文件
excel_files <- list.files(excel_files_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 处理每个 Excel 文件
for (excel_file in excel_files) {
  # 读取 Excel 文件的数据
  df <- read_excel(excel_file, sheet = "Sheet1")
  
  # 确保所有的 NA 值被替换为 0
  df[is.na(df)] <- 0
  
  # 提取作物列名（跳过 YEAR 列）
  crop_columns <- colnames(df)[-1]
  
  # 初始化结果数据框
  results <- df %>% select(YEAR)
  results$Total_P_removal <- 0
  
  # 遍历每个作物列，计算 P removal rate 并求和
  for (crop in crop_columns) {
    if (crop %in% names(coefficients_pool)) {
      # 获取作物的系数区间
      coefficient_range <- coefficients_pool[[crop]]
      # 根据开关选择相应的系数
      coefficient <- get_coefficient(coefficient_range, getOption("global_vars")$monte_carlo_mode)
      # 计算作物的 P removal rate
      results[[paste0(crop, "_P_removal")]] <- df[[crop]] * coefficient
      results$Total_P_removal <- results$Total_P_removal + results[[paste0(crop, "_P_removal")]]
    }
  }
  
  # 获取输出文件的名称和路径
  output_file_name <- basename(excel_file)
  output_file_path <- file.path(output_folder, output_file_name)
  
  # 保存包含 YEAR, Total_P_removal 和 各作物 P removal rate 的数据到新的 Excel 文件中
  write_xlsx(results, output_file_path)
  
  # 打印处理状态
  cat("Processed and saved:", output_file_path, "\n")
}

print("All files have been processed and saved.")





###########################################################################################
################################## Crop residue P removal #################################
###########################################################################################

# 清空环境
rm(list=ls())

######### Crop residue P content with Monte Carlo #########

# 定义 coefficients pool 为区间（最小值和最大值）
coefficients_pool <- list(
  Spring_wheat = c(1.6*0.072/100, 1.6*0.088/100),  # 0.08 +/- 10%
  Winter_wheat = c(1.2*0.072/100, 1.2*0.088/100),
  Durum_wheat = c(1.66*0.072/100, 1.66*0.088/100),
  Corn_grain = c(1*0.117/100, 1*0.143/100),        # 0.13 +/- 10%
  Corn_silage = c(1*0.117/100, 1*0.143/100),
  Cotton = c(3*0.135/100, 3*0.165/100),            # 0.15 +/- 10%
  Oats = c(1.5*0.126/100, 1.5*0.154/100),          # 0.14 +/- 10%
  Barley = c(1*0.099/100, 1*0.121/100),            # 0.11 +/- 10%
  Millet = c(1.5*0.09/100, 1.5*0.11/100),          # 0.10 +/- 10%
  Rye = c(1.5*0.063/100, 1.5*0.077/100),           # 0.07 +/- 10%
  Rice = c(1*0.108/100, 1*0.132/100),              # 0.12 +/- 10%
  Sorghum_grain = c(1*0.162/100, 1*0.198/100),     # 0.18 +/- 10%
  Sorghum_silage = c(1*0.162/100, 1*0.198/100),
  Flaxseed = c(0.5*0.117/100, 0.5*0.143/100),      # 0.13 +/- 10%
  Peanuts = c(1.5*0.135/100, 1.5*0.165/100),       # 0.15 +/- 10%
  Soybeans = c(1.5*0.171/100, 1.5*0.209/100),      # 0.19 +/- 10%
  Canola = c(1.5*0.09/100, 1.5*0.11/100),          # 0.10 +/- 10%
  Sunflower = c(2*0.036/100, 2*0.044/100),         # 0.04 +/- 10%
  Peas = c(1.2*0.099/100, 1.2*0.121/100),          # 0.11 +/- 10%
  Sugarbeets = c(1*0.045/100, 1*0.055/100),        # 0.05 +/- 10%
  Potatoes = c(0.5*0.027/100, 0.5*0.033/100),      # 0.03 +/- 10%
  Rapeseed = c(1.5*0.09/100, 1.5*0.11/100)         # 0.10 +/- 10%
)

# 设置包含 Excel 数据文件的目录
excel_files_dir <- "Initial data/Crop production" # 替换为实际的目录

# 设置输出文件夹
output_folder <- "P cycling/Crop residue P removal"

# 创建输出文件夹（递归创建）
if (!dir.exists(output_folder)) {
  dir.create(output_folder, recursive = TRUE)
}

# 设置开关，控制蒙特卡洛模拟模式
get_coefficient <- function(coefficient_range, mode) {
  if (mode == 1) {
    # 5% 分位数
    return(coefficient_range[1] + 0.05 * (coefficient_range[2] - coefficient_range[1]))
  } else if (mode == 2) {
    # 均值
    return(mean(coefficient_range))
  } else if (mode == 3) {
    # 95% 分位数
    return(coefficient_range[1] + 0.95 * (coefficient_range[2] - coefficient_range[1]))
  }
}

# 列出目录中的所有 Excel 文件
excel_files <- list.files(excel_files_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 处理每个 Excel 文件
for (excel_file in excel_files) {
  # 读取 Excel 文件的数据
  df <- read_excel(excel_file, sheet = "Sheet1")
  
  # 确保所有的 NA 值被替换为 0
  df[is.na(df)] <- 0
  
  # 提取作物列名（跳过 YEAR 列）
  crop_columns <- colnames(df)[-1]
  
  # 初始化结果数据框
  results <- df %>% select(YEAR)
  results$Total_P_removal <- 0
  
  # 遍历每个作物列，计算 P removal rate 并求和
  for (crop in crop_columns) {
    if (crop %in% names(coefficients_pool)) {
      # 获取作物的系数区间
      coefficient_range <- coefficients_pool[[crop]]
      # 根据开关选择相应的系数
      coefficient <- get_coefficient(coefficient_range, getOption("global_vars")$monte_carlo_mode)
      # 计算作物的 P removal rate
      results[[paste0(crop, "_P_removal")]] <- df[[crop]] * coefficient
      results$Total_P_removal <- results$Total_P_removal + results[[paste0(crop, "_P_removal")]]
    }
  }
  
  # 仅保留存在于 coefficients_pool 的作物列
  results <- results %>% select(YEAR, Total_P_removal, ends_with("_P_removal"))
  
  # 获取输出文件的名称和路径
  output_file_name <- basename(excel_file)
  output_file_path <- file.path(output_folder, output_file_name)
  
  # 保存包含 YEAR, Total_P_removal 和 各作物 P removal rate 的数据到新的 Excel 文件中
  write_xlsx(results, output_file_path)
  
  # 打印处理状态
  cat("Processed and saved:", output_file_path, "\n")
}

print("All files have been processed and saved.")




##########################################################################################
################################## Crop residue P return #################################
##########################################################################################
# 清空环境
rm(list=ls())

# 设置文件目录
input_folder <- "P cycling/Crop residue P removal"
recycling_rate_folder <- "Initial data/Preprocess/Crop residue recycling rate"
output_folder <- "P cycling/Crop residue P return"

# 创建输出文件夹（递归创建）
if (!dir.exists(output_folder)) {
  dir.create(output_folder, recursive = TRUE)
}

# 列出输入目录中的所有 Excel 文件
input_files <- list.files(input_folder, pattern = "\\.xlsx$", full.names = TRUE)

# 读取默认的回收率数据
other_recycling_rate_file <- file.path(recycling_rate_folder, "Other.xlsx")
if (file.exists(other_recycling_rate_file)) {
  other_recycling_rate_df <- read_excel(other_recycling_rate_file)
} else {
  stop("Other.xlsx file not found in the recycling rate folder.")
}

# 初始化信息列表
info_list <- list()

# 处理每个输入 Excel 文件
for (input_file in input_files) {
  # 读取输入 Excel 文件的数据
  df <- read_excel(input_file)
  
  # 提取州名
  state_name <- tools::file_path_sans_ext(basename(input_file))
  
  # 移除 Total_P_removal 列
  df <- df %>% select(-Total_P_removal)
  
  # 提取作物列名（跳过 YEAR 列）
  crop_columns <- colnames(df)[-1]
  
  # 初始化结果数据框
  results <- df %>% select(YEAR)
  
  # 初始化 Total 列
  results$Total <- 0
  
  # 遍历每个作物列
  for (crop in crop_columns) {
    tryCatch({
      # 找到与列名对应的回收率文件
      recycling_rate_file <- file.path(recycling_rate_folder, paste0(crop, ".xlsx"))
      
      if (file.exists(recycling_rate_file)) {
        # 读取回收率数据
        recycling_rate_df <- read_excel(recycling_rate_file)
        
        # 确保回收率数据包含州名列并与输入数据匹配
        if (state_name %in% colnames(recycling_rate_df) && all(recycling_rate_df$YEAR == df$YEAR)) {
          # 相乘计算结果
          results[[crop]] <- df[[crop]] * recycling_rate_df[[state_name]]
        } else {
          message <- paste("Recycling rate file does not match YEAR column for crop:", crop, "in file:", input_file)
          info_list <- append(info_list, message)
        }
      } else {
        message <- paste(crop, "using Other.xlsx in file:", input_file)
        info_list <- append(info_list, message)
        # 使用 Other.xlsx 数据
        if (state_name %in% colnames(other_recycling_rate_df) && all(other_recycling_rate_df$YEAR == df$YEAR)) {
          results[[crop]] <- df[[crop]] * other_recycling_rate_df[[state_name]]
        } else {
          message <- paste("Other.xlsx file does not match YEAR column or state column for crop:", crop, "in file:", input_file)
          info_list <- append(info_list, message)
        }
      }
      # 更新 Total 列
      if (crop %in% colnames(results)) {
        results$Total <- results$Total + results[[crop]]
      }
    }, warning = function(w) {
      message <- paste("Warning in processing crop:", crop, "in file:", input_file, "-", conditionMessage(w))
      info_list <- append(info_list, message)
    }, error = function(e) {
      message <- paste("Error in processing crop:", crop, "in file:", input_file, "-", conditionMessage(e))
      info_list <- append(info_list, message)
    })
  }
  
  # 获取输出文件的名称和路径
  output_file_name <- basename(input_file)
  output_file_path <- file.path(output_folder, output_file_name)
  
  # 保存结果到新的 Excel 文件中
  write_xlsx(results, output_file_path)
  
  # 打印处理状态
  cat("Processed and saved:", output_file_path, "\n")
}

# 打印所有信息
if (length(info_list) > 0) {
  cat("Information:\n")
  for (message in info_list) {
    cat(message, "\n")
  }
} else {
  print("No warnings encountered.")
}

print("All files have been processed and saved.")