
#####################################################################################################
####################################### Food waste crop P ###########################################
#####################################################################################################

# 加载必要的包
library(readxl)
library(dplyr)
library(writexl)

# 清空环境
rm(list=ls())

############# Crop P removal and residue P removal 求和 ###########
# 先计算 crop P removal 各类的和

# 定义Grain、Beans和Hay的列名
grain_columns <- c('Barley', 'Corn_grain', 'Corn_silage', 'Durum_wheat', 'Millet', 'Oats', 'Rice', 'Rye', 'Sorghum_grain', 'Sorghum_silage', 'Spring_wheat', 'Winter_wheat')
beans_columns <- c('Beans', 'Lentils', 'Peas', 'Soybeans')
hay_columns <- c('Hay', 'Haylage')

# 定义文件路径
input_dir1 <- "P cycling/Crop P removal"
input_dir2 <- "P cycling/Crop residue P removal"

# 获取目录下的所有Excel文件
excel_files1 <- list.files(input_dir1, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)
excel_files2 <- list.files(input_dir2, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)

process_file_summaries <- function(file1, file2) {
  # 读取两个Excel文件
  df1 <- read_excel(file1)
  df2 <- read_excel(file2)
  
  # 去掉列名中的"_P_removal"（除了第一、二列）
  colnames(df1)[3:ncol(df1)] <- gsub("_P_removal", "", colnames(df1)[3:ncol(df1)])
  colnames(df2)[3:ncol(df2)] <- gsub("_P_removal", "", colnames(df2)[3:ncol(df2)])
  
  # 计算Grain_SUM_P_removal
  df1 <- df1 %>% mutate(Grain_sum = rowSums(select(., any_of(grain_columns)), na.rm = TRUE))
  df2 <- df2 %>% mutate(Grain_sum = rowSums(select(., any_of(grain_columns)), na.rm = TRUE))
  
  # 计算Beans_SUM_P_removal（如果存在）
  if (any(beans_columns %in% colnames(df1))) {
    df1 <- df1 %>% mutate(Beans_sum = rowSums(select(., any_of(beans_columns)), na.rm = TRUE))
  }
  if (any(beans_columns %in% colnames(df2))) {
    df2 <- df2 %>% mutate(Beans_sum = rowSums(select(., any_of(beans_columns)), na.rm = TRUE))
  }
  
  # 计算Hay_SUM_P_removal（如果存在）
  if (any(hay_columns %in% colnames(df1))) {
    df1 <- df1 %>% mutate(Hay_sum = rowSums(select(., any_of(hay_columns)), na.rm = TRUE))
  }
  if (any(hay_columns %in% colnames(df2))) {
    df2 <- df2 %>% mutate(Hay_sum = rowSums(select(., any_of(hay_columns)), na.rm = TRUE))
  }
  
  # 检查并计算Fruit_sum、Vegetable_sum、Nut_sum的总和（如果存在）
  if ("Fruit_sum" %in% colnames(df1)) {
    df1 <- df1 %>% mutate(Fruit_sum = df1$Fruit_sum)
  }
  if ("Vegetable_sum" %in% colnames(df1)) {
    df1 <- df1 %>% mutate(Vegetable_sum = df1$Vegetable_sum)
  }
  if ("Nut_sum" %in% colnames(df1)) {
    df1 <- df1 %>% mutate(Nut_sum = df1$Nut_sum)
  }
  
  if ("Fruit_sum" %in% colnames(df2)) {
    df2 <- df2 %>% mutate(Fruit_sum = df2$Fruit_sum)
  }
  if ("Vegetable_sum" %in% colnames(df2)) {
    df2 <- df2 %>% mutate(Vegetable_sum = df2$Vegetable_sum)
  }
  if ("Nut_sum" %in% colnames(df2)) {
    df2 <- df2 %>% mutate(Nut_sum = df2$Nut_sum)
  }
  
  list(df1 = df1, df2 = df2)
}

#################### 不同类 Crop P removal 占比 #####################
# 再计算各类crop P removal 占总和的比例

# 定义文件路径
output_dir <- "P cycling/Crop P removal proportion"

# 确保输出目录存在
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 定义需要求和和计算比例的列名
sum_columns <- c("Total_P_removal", "Grain_sum", "Fruit_sum", "Vegetable_sum", "Nut_sum", "Beans_sum", "Hay_sum")

process_file_proportion <- function(df1, df2, output_file) {
  # 初始化结果数据框
  result_df <- df1 %>% select(YEAR)
  
  # 计算Total_P_removal总和
  result_df$Total_P_removal <- rowSums(cbind(df1[["Total_P_removal"]], df2[["Total_P_removal"]]), na.rm = TRUE)
  
  # 计算其他列的总和或直接使用
  for (col in sum_columns[-1]) { # 除去Total_P_removal列
    col_1 <- if (col %in% colnames(df1)) df1[[col]] else 0
    col_2 <- if (col %in% colnames(df2)) df2[[col]] else 0
    result_col <- rowSums(cbind(col_1, col_2), na.rm = TRUE)
    if (sum(result_col, na.rm = TRUE) != 0) {
      result_df[[col]] <- result_col
      result_df[[paste0(col, "_proportion")]] <- result_col / result_df$Total_P_removal
    }
  }
  
  # 保存处理后的结果到新的Excel文件
  write_xlsx(result_df, output_file)
}

# 逐个处理文件
for (file_name in basename(excel_files1)) {
  file1 <- file.path(input_dir1, file_name)
  file2 <- file.path(input_dir2, file_name)
  
  if (file.exists(file2)) {
    output_file <- file.path(output_dir, file_name)
    summaries <- process_file_summaries(file1, file2)
    process_file_proportion(summaries$df1, summaries$df2, output_file)
  }
}

print("处理完成，结果已保存。")

#################### 不同类Crop P fertilizer applied #################
# 基于各类crop P removal占总 P removal的比，得到各类crop需要消耗的mineral P fertilizer

# 清空环境
rm(list=ls())

# 定义文件路径
input_dir1 <- "P cycling/Crop P removal proportion"
input_dir2 <- "P cycling/Fertilizer P cropland"
output_dir <- "P cycling/Crop P applied"

# 确保输出目录存在
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 获取P cycling/Crop P removal proportion目录下的所有Excel文件
excel_files1 <- list.files(input_dir1, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)

# 定义需要计算的列名
calc_columns <- c("Grain_sum_proportion", "Fruit_sum_proportion", "Vegetable_sum_proportion", "Nut_sum_proportion", "Beans_sum_proportion", "Hay_sum_proportion")

process_file_need <- function(file1, file2, output_file) {
  tryCatch({
    # 读取两个Excel文件
    df1 <- read_excel(file1)
    df2 <- read_excel(file2)
    
    # 获取P2O5_CONSUMPTION列
    P_CONSUMPTION <- df2[[2]]
    
    # 初始化结果数据框
    result_df <- df1 %>% select(YEAR)
    
    # 计算每个列乘以P2O5_CONSUMPTION后的结果，并重命名列
    for (col in calc_columns) {
      if (col %in% colnames(df1)) {
        new_col_name <- gsub("_proportion", "_P", col)
        result_df[[new_col_name]] <- df1[[col]] * P_CONSUMPTION
      }
    }
    
    # 保存处理后的结果到新的Excel文件
    write_xlsx(result_df, output_file)
  }, warning = function(w) {
    warning_message <- paste("Warning in file:", basename(file1), "and", basename(file2), ":", conditionMessage(w))
    message(warning_message)
    cat(warning_message, "\n", file = "warnings.log", append = TRUE)
  }, error = function(e) {
    error_message <- paste("Error in file:", basename(file1), "and", basename(file2), ":", conditionMessage(e))
    message(error_message)
    cat(error_message, "\n", file = "errors.log", append = TRUE)
  })
}

# 逐个处理文件
for (file_name in basename(excel_files1)) {
  file1 <- file.path(input_dir1, file_name)
  file2 <- file.path(input_dir2, file_name)
  
  if (file.exists(file2)) {
    output_file <- file.path(output_dir, file_name)
    process_file_need(file1, file2, output_file)
  }
}

print("处理完成，结果已保存。")

#################### Crop P fertilizer waste with uncertainty #####################
# 清空环境
rm(list=ls())

# 定义函数
process_crop_fertilizer_recycling <- function(sheet_name, output_subdir, scaling_factor = 1) {
  # 定义目录
  crop_species_dir <- "P cycling/Crop P applied"
  food_waste_file <- "Initial data/Preprocess/Food waste/Food waste crop.xlsx"
  output_dir <- file.path("P cycling", output_subdir)
  
  # 如果输出目录不存在则创建
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # 读取 Food waste crop 数据
  food_waste_data <- read_excel(food_waste_file, sheet = sheet_name) %>%
    filter(YEAR >= 1995 & YEAR <= 2050)
  
  # 将系数列（排除 'YEAR' 列）乘以缩放系数
  food_waste_data <- food_waste_data %>%
    mutate(across(-YEAR, ~ . * scaling_factor))  # 排除 'YEAR' 列
  
  # 定义处理每个作物物种文件的函数
  process_file <- function(file_path) {
    # 读取作物物种肥料需求数据
    crop_data <- read_excel(file_path) %>%
      filter(YEAR >= 1995 & YEAR <= 2050) %>%
      rename_with(~ gsub("_P$", "", .))
    
    # 找到匹配的列
    matching_columns <- intersect(names(crop_data), names(food_waste_data))
    
    # 确保 'YEAR' 包含在匹配列中
    matching_columns <- c("YEAR", matching_columns[matching_columns != "YEAR"])
    
    # 子集数据以匹配的列
    crop_data <- crop_data %>% select(all_of(matching_columns))
    food_waste_data_subset <- food_waste_data %>% select(all_of(matching_columns))
    
    # 对应数据相乘
    result_data <- crop_data
    result_data[,-1] <- crop_data[,-1] * food_waste_data_subset[,-1]
    
    # 添加 Sum 列
    result_data$Sum <- rowSums(result_data[,-1])
    
    # 保存结果到新文件
    output_file <- file.path(output_dir, paste0(basename(file_path)))
    write_xlsx(result_data, output_file)
  }
  
  # 获取作物物种肥料需求目录中的Excel文件列表
  file_list <- list.files(crop_species_dir, pattern = "*.xlsx", full.names = TRUE)
  
  # 处理每个文件
  invisible(lapply(file_list, process_file))
  
  cat("处理完成。结果已保存到：", output_dir, "\n")
}

# 通过开关控制不同的系数，分别处理 Sheet1 和 Sheet2 情景
scaling_factor <- switch(getOption("global_vars")$monte_carlo_mode,
                         "1" = 0.8,  # 当 scaling_switch == 1 时
                         "2" = 1,    # 当 scaling_switch == 2 时
                         "3" = 1.2)  # 当 scaling_switch == 3 时

process_crop_fertilizer_recycling("Sheet1", "Crop waste P fertilizer 2030 Goal", scaling_factor)
process_crop_fertilizer_recycling("Sheet2", "Crop waste P fertilizer 2030 unchanged", scaling_factor)
