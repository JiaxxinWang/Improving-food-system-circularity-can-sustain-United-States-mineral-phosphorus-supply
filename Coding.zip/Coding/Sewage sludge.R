
##############################################################################################
####################################### Human sewage P #######################################
##############################################################################################


# 加载必要的库
library(readxl)
library(openxlsx)
library(dplyr)
library(rstudioapi)


###################### 计算Total human municipal sewage P production with uncertainty ###################
# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义输入和输出文件夹路径
input_dir <- "Initial data/Population process"
output_dir <- "P cycling/Human sewage P production"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 列出输入目录中的所有Excel文件
population_files <- list.files(input_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 定义特定州的detergent折算系数
specific_states <- c("ILLINOIS", "INDIANA", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", 
                     "MINNESOTA", "MONTANA", "NEW HAMPSHIRE", "NEW YORK", "OHIO", 
                     "OREGON", "PENNSYLVANIA", "UTAH", "VIRGINIA", "VERMONT", 
                     "WASHINGTON", "WISCONSIN")

# scaling_switch <- 2 
scaling_factor <- switch(getOption("global_vars")$monte_carlo_mode,
                         "1" = 0.8,  
                         "2" = 1,    
                         "3" = 1.2)  

# 处理每个Excel文件
for (population_file in population_files) {
  # 读取Excel文件
  data <- read_excel(population_file)
  
  # 获取文件名（不包含扩展名）
  state_name <- tools::file_path_sans_ext(basename(population_file))
  
  # 根据年份和州名应用不同的detergent系数
  detergent_before2010 = (0.5 / 1000) * scaling_factor  # 0.5kg/population
  detergent_after2010_specificstate = (0.1643 / 1000) * scaling_factor
  detergent_after2010_otherstate = (0.21 / 1000) * scaling_factor 
  humanexcrete_coefficient = (0.511 / 1000) * scaling_factor
  
  data <- data %>%
    mutate(
      Detergent = case_when(
        YEAR < 2010 ~ Population * detergent_before2010,
        YEAR >= 2010 & state_name %in% specific_states ~ Population * detergent_after2010_specificstate,
        YEAR >= 2010 ~ Population * detergent_after2010_otherstate
      ),
      Human_Excrete = Population * humanexcrete_coefficient,
      Total = Detergent + Human_Excrete
    ) %>%
    select(YEAR, Detergent, Human_Excrete, Total)
  
  # 定义输出文件路径
  output_file_path <- file.path(output_dir, paste0(state_name, ".xlsx"))
  
  # 将处理后的数据保存为新的Excel文件
  write.xlsx(data, file = output_file_path, rowNames = FALSE)
  
  # 打印处理状态
  cat("Processed and saved:", output_file_path, "\n")
}

print("所有文件已成功处理并保存。")



########################### 计算 Sewage treatment from human sewage P production ###############

# 清空环境
rm(list = ls())

# 定义文件夹路径
human_sewage_dir <- "P cycling/Human sewage P production"
sewage_treatment_dir <- "Initial data/Preprocess/Sewage coefficient"
output_dir <- "P cycling/Sewage treatment P"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 读取Dconn.xlsx
dconn_file <- file.path(sewage_treatment_dir, "Dconn.xlsx")
dconn_data <- read_excel(dconn_file)

# 读取Sewage treatment proportion.xlsx
sewage_treatment_file <- file.path(sewage_treatment_dir, "Sewage treatment proportion.xlsx")
sewage_treatment_data <- read_excel(sewage_treatment_file)

# 列出Human sewage目录中的所有Excel文件
human_sewage_files <- list.files(human_sewage_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 处理每个Human sewage Excel文件
for (human_sewage_file in human_sewage_files) {
  # 读取Human sewage Excel文件
  data <- read_excel(human_sewage_file) %>%
    select(YEAR, Total)
  
  # 获取文件名（不包含扩展名）
  state_name <- tools::file_path_sans_ext(basename(human_sewage_file))
  
  # 计算第一个折算系数（Dconn中的Coefficient乘以Total）
  combined_data <- data %>%
    left_join(dconn_data, by = "YEAR") %>%
    mutate(Result = Total * Coefficient)
  
  # 计算第二个折算系数
  if (state_name %in% colnames(sewage_treatment_data)) {
    treatment_col <- sewage_treatment_data[[state_name]]
    second_coefficient <- sum(treatment_col[1] * 0.5, 
                              treatment_col[2] * 0.51, 
                              treatment_col[3] * 0.85, 
                              treatment_col[4] * 1, 
                              na.rm = TRUE)
  } else {
    second_coefficient <- 1 # 如果没有找到匹配的列名，默认系数为1
  }
  
  # 将第一个折算系数的结果乘以第二个折算系数，并更改列名
  final_data <- combined_data %>%
    mutate(Sew_treatment = Result * second_coefficient) %>%
    select(YEAR, Sew_treatment)
  
  # 定义输出文件路径
  output_file_path <- file.path(output_dir, paste0(state_name, ".xlsx"))
  
  # 将处理后的数据保存为新的Excel文件
  write.xlsx(final_data, file = output_file_path, rowNames = FALSE)
  
  # 打印处理状态
  cat("Processed and saved:", output_file_path, "\n")
}

print("所有文件已成功处理并保存。")



############################## 计算 Sewage P loss after sewage treatment ###################

# 清空环境
rm(list = ls())

# 定义文件夹路径
human_sewage_dir <- "P cycling/Human sewage P production"
sewage_treatment_dir <- "P cycling/Sewage treatment P"
output_dir <- "P cycling/Sewage emission P"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 列出Human sewage目录中的所有Excel文件
human_sewage_files <- list.files(human_sewage_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 处理每个Human sewage Excel文件
for (human_sewage_file in human_sewage_files) {
  # 读取Human sewage Excel文件
  human_sewage_data <- read_excel(human_sewage_file) %>%
    select(YEAR, Total)
  
  # 获取文件名（不包含扩展名）
  state_name <- tools::file_path_sans_ext(basename(human_sewage_file))
  
  # 定义对应的Sewage treatment文件路径
  sewage_treatment_file <- file.path(sewage_treatment_dir, paste0(state_name, ".xlsx"))
  
  # 读取Sewage treatment Excel文件
  if (file.exists(sewage_treatment_file)) {
    sewage_treatment_data <- read_excel(sewage_treatment_file) %>%
      select(YEAR, Sew_treatment)
    
    # 合并两个数据框，并计算差值
    combined_data <- human_sewage_data %>%
      left_join(sewage_treatment_data, by = "YEAR") %>%
      mutate(Sew_emission = Total - Sew_treatment) %>%
      select(YEAR, Sew_emission)
    
    # 定义输出文件路径
    output_file_path <- file.path(output_dir, paste0(state_name, ".xlsx"))
    
    # 将处理后的数据保存为新的Excel文件
    write.xlsx(combined_data, file = output_file_path, rowNames = FALSE)
    
    # 打印处理状态
    cat("Processed and saved:", output_file_path, "\n")
  } else {
    cat("Sewage treatment file not found for:", state_name, "\n")
  }
}

print("所有文件已成功处理并保存。")



############################### 计算 Sewage treatment P used in agriculture ####################

# 清空环境
rm(list = ls())

# 定义文件夹路径
sewage_treatment_dir <- "P cycling/Sewage treatment P"
sewage_coefficient_dir <- "Initial data/Preprocess/Sewage coefficient"
output_agriculture_dir <- "P cycling/Sewage treatment P used in agriculture"
output_landfill_dir <- "P cycling/Sewage treatment P in landfill"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_agriculture_dir)) {
  dir.create(output_agriculture_dir, recursive = TRUE)
}

if (!dir.exists(output_landfill_dir)) {
  dir.create(output_landfill_dir, recursive = TRUE)
}

# 读取Drecy.xlsx
drecy_file <- file.path(sewage_coefficient_dir, "Drecy.xlsx")
drecy_data <- read_excel(drecy_file)

# 列出Sewage treatment目录中的所有Excel文件
sewage_treatment_files <- list.files(sewage_treatment_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 处理每个Sewage treatment Excel文件
for (sewage_treatment_file in sewage_treatment_files) {
  # 读取Sewage treatment Excel文件
  sewage_treatment_data <- read_excel(sewage_treatment_file) %>%
    select(YEAR, Sew_treatment)
  
  # 获取文件名（不包含扩展名）
  state_name <- tools::file_path_sans_ext(basename(sewage_treatment_file))
  
  # 合并数据并计算Sew_agriculture和Sew_landfill
  combined_data <- sewage_treatment_data %>%
    left_join(drecy_data, by = "YEAR") %>%
    mutate(Sew_agriculture = Sew_treatment * Coefficient,
           Sew_landfill = Sew_treatment - Sew_agriculture) %>%
    select(YEAR, Sew_agriculture, Sew_landfill)
  
  # 定义输出文件路径
  output_agriculture_file_path <- file.path(output_agriculture_dir, paste0(state_name, ".xlsx"))
  output_landfill_file_path <- file.path(output_landfill_dir, paste0(state_name, ".xlsx"))
  
  # 保存Sew_agriculture数据
  write.xlsx(combined_data %>% select(YEAR, Sew_agriculture), file = output_agriculture_file_path, rowNames = FALSE)
  
  # 保存Sew_landfill数据
  write.xlsx(combined_data %>% select(YEAR, Sew_landfill), file = output_landfill_file_path, rowNames = FALSE)
  
  # 打印处理状态
  cat("Processed and saved:", output_agriculture_file_path, "\n")
  cat("Processed and saved:", output_landfill_file_path, "\n")
}

print("所有文件已成功处理并保存。")
