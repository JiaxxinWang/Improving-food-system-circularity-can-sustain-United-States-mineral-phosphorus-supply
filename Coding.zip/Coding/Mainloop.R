# 计算uncertainty是首先monte carlo，然后是降雨PRCP调整RCP scenario (8.5)，Population immigration scenario (Zero)

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 创建自定义环境
global_vars <- new.env()

# 在该环境中定义变量
global_vars$monte_carlo_mode <- 2

# 将自定义环境保存在 R 的全局选项中
options(global_vars = global_vars)

# 通过 getOption("global_vars")$monte_carlo_mode 获得变量

# 运行主要程序
################################################################################
source("Atmospheric deposition.R")

# 运行 monte_carlo_mode设置
source("Crop P removal.R")

source("Fertilizer P partition.R")

# 运行 monte_carlo_mode设置
source("Eggshell P.R")

# 运行 monte_carlo_mode设置
source("Livestock bone P.R")

# 运行 monte_carlo_mode设置
source("Crop waste P.R")

# 运行 monte_carlo_mode设置
source("Red meat waste P.R")

# 运行 monte_carlo_mode设置
source("Poultry meat waste P.R")

# 运行 monte_carlo_mode设置
source("Sewage sludge.R")

# 运行 monte_carlo_mode设置
source("Livestock.R")

source("Weathering.R")

source("P balance.R")

source("DPPS cropland historical.R")

source("DPPS pastureland historical.R")

################################################################################

# 运行汇总程序
################################################################################
source("州数据汇总.R")
source("州数据求和.R")
source("国数据求和.R")
################################################################################

# 运行county-level程序
################################################################################
source("降尺度 14 cattlehog manure P loss county.R")
source("降尺度 14 chicken manure P loss county.R")
source("降尺度 Crop P removal county.R")
source("降尺度 Crop P residue loss county.R")
source("降尺度 Crop waste county.R")
source("降尺度 Eggshell P county.R")
source("降尺度 Fertilizer P application county.R")
source("降尺度 Livestock bone P cattlehog county.R")
source("降尺度 Livestock bone P chicken county.R")
source("降尺度 Livestock bone P other county.R")
source("降尺度 Poultry meat waste P county.R")
source("降尺度 Red meat waste P county.R")
source("降尺度 Sewage sludge waste P county.R")
source("降尺度 Soil labile P county.R")
source("降尺度 Soil legacy P county.R")
source("降尺度 Soil P loss county.R")
source("降尺度 Soil stable P county.R")
################################################################################

# 运行汇总程序
################################################################################
# 超长代码运行时间
source("县数据汇总.R")

source("县数据求和.R")
source("Crop P removal nation.R")
source("县数据求和汇总csv.R")
#source("经济效益计算.R")
source("州数据汇总文件夹.R")
################################################################################
print('所有R模块数据已经处理完成')