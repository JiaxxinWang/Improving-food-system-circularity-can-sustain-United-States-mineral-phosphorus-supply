# 加载必要的库
library(readxl)
library(dplyr)
library(openxlsx)

# 清空工作环境
rm(list = ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 设置文件夹路径
livestock_folder <- "Preprocess/Livestock"
proportion_folder <- "Preprocess/Livestock slaughter proportion"
output_folder <- "Livestock slaughter head"

# 创建“Livestock slaughter”文件夹（如果不存在）
if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

# 获取 Livestock 文件夹和 Proportion 文件夹中所有 Excel 文件名
livestock_files <- list.files(livestock_folder, pattern = "\\.xlsx$", full.names = TRUE)
proportion_files <- list.files(proportion_folder, pattern = "\\.xlsx$", full.names = TRUE)

# 逐一处理每个 Livestock 文件
for (livestock_file in livestock_files) {
  # 提取文件名（不带路径和扩展名）
  file_name <- tools::file_path_sans_ext(basename(livestock_file))
  
  # 读取对应的 Livestock 和 Proportion 文件
  livestock_data <- read_excel(livestock_file)
  proportion_file <- file.path(proportion_folder, paste0(file_name, ".xlsx"))
  proportion_data <- read_excel(proportion_file)
  
  # 确保 LOCATION 和 State 列正确匹配
  merged_data <- livestock_data %>%
    left_join(proportion_data, by = c("LOCATION" = "State"))
  
  # 计算调整后的 Head 值，并四舍五入为整数
  result_data <- merged_data %>%
    mutate(Head = round(Head * Average_Proportion)) %>%  # 四舍五入并改名为 Head
    select(YEAR, LOCATION, Head)  # 保留所需列
  
  # 导出结果到 Livestock slaughter 文件夹
  output_path <- file.path(output_folder, paste0(file_name, ".xlsx"))
  write.xlsx(result_data, output_path)
  
  # 显示进度
  message("Processed and saved: ", output_path)
}

# 显示完成消息
print("所有文件已处理完成并导出到 Livestock slaughter head 文件夹")
