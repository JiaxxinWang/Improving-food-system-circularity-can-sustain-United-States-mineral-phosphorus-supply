#############################################################################################
###################################### Cropland P balance ###################################
#############################################################################################

# 加载必要的包
library(dplyr)
library(readxl)
library(openxlsx)
library(rstudioapi)

# 清空环境
rm(list = ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义文件夹路径
folders <- list(
  crop_area = "Initial data/Crop area",
  runoff_loss_coefficient = "Initial data/Runoff loss coefficient cropland",
  crop_p_removal_proportion = "P cycling/Crop P removal proportion",
  atmospheric_deposition = "P cycling/Atmospheric deposition - cropland",
  weathering = "P cycling/Weathering - cropland",
  sew_agriculture = "P cycling/Sewage treatment P used in agriculture",
  fertilizer_p = "P cycling/Fertilizer P cropland",
  livestock_manure_p_recovery = "P cycling/6 livestock manure P recovery",
  confined_manure_p_recovery = "P cycling/14 livestock confined manure P recovery",
  nonconfined_manure_p_recovery = "P cycling/14 livestock nonconfined manure P recovery",
  crop_residue_p_return = "P cycling/Crop residue P return"
)

output_dir <- "P cycling/P balance cropland"
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 定义每个州的 coefficient_to_cropland 值
coefficient_to_cropland <- list(
  "ALABAMA" = 0.5,   
  "ALASKA" = 0,
  "ARIZONA" = 0,
  "ARKANSAS" = 1,
  "CALIFORNIA" = 0.2,
  "COLORADO" = 1,
  "CONNECTICUT" = 1,
  "DELAWARE" = 1,
  "FLORIDA" = 0,
  "GEORGIA" = 0,
  "HAWAII" = 0,
  "IDAHO" = 1,
  "ILLINOIS" = 1,
  "INDIANA" = 1,
  "IOWA" = 1,
  "KANSAS" = 1,
  "KENTUCKY" = 1,
  "LOUISIANA" = 1,
  "MAINE" = 1,
  "MARYLAND" = 1,
  "MASSACHUSETTS" = 0.8,
  "MICHIGAN" = 1,
  "MINNESOTA" = 1,
  "MISSISSIPPI" = 1,
  "MISSOURI" = 1,
  "MONTANA" = 1,
  "NEBRASKA" = 1,
  "NEVADA" = 0.4,
  "NEW HAMPSHIRE" = 1,
  "NEW JERSEY" = 0.5,
  "NEW MEXICO" = 1,
  "NEW YORK" = 1,
  "NORTH CAROLINA" = 0,
  "NORTH DAKOTA" = 1,
  "OHIO" = 1,
  "OKLAHOMA" = 1,
  "OREGON" = 1,
  "PENNSYLVANIA" = 1,
  "RHODE ISLAND" = 0,
  "SOUTH CAROLINA" = 1,
  "SOUTH DAKOTA" = 1,
  "TENNESSEE" = 1,
  "TEXAS" = 0.7,
  "UTAH" = 0.9,
  "VERMONT" = 1,
  "VIRGINIA" = 1,
  "WASHINGTON" = 1,
  "WEST VIRGINIA" = 1,
  "WISCONSIN" = 1,
  "WYOMING" = 0.5
)

# 获取crop area文件夹下的所有Excel文件
crop_area_files <- list.files(folders$crop_area, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)

# 处理每个文件
for (crop_area_file in crop_area_files) {
  # 获取文件名（去掉路径和扩展名）
  file_name <- tools::file_path_sans_ext(basename(crop_area_file))
  
  # 获取当前州的coefficient_to_cropland值
  current_coefficient <- coefficient_to_cropland[[toupper(file_name)]]
  
  # 读取所有相关文件
  crop_area_data <- read_excel(crop_area_file)
  atmospheric_data <- read_excel(file.path(folders$atmospheric_deposition, paste0(file_name, ".xlsx")))
  weathering_data <- read_excel(file.path(folders$weathering, paste0(file_name, ".xlsx")))
  sew_agriculture_data <- read_excel(file.path(folders$sew_agriculture, paste0(file_name, ".xlsx")))
  fertilizer_p_data <- read_excel(file.path(folders$fertilizer_p, paste0(file_name, ".xlsx")))
  livestock_manure_p_recovery_data <- read_excel(file.path(folders$livestock_manure_p_recovery, paste0(file_name, ".xlsx")))
  confined_manure_p_recovery_data <- read_excel(file.path(folders$confined_manure_p_recovery, paste0(file_name, ".xlsx")))
  nonconfined_manure_p_recovery_data <- read_excel(file.path(folders$nonconfined_manure_p_recovery, paste0(file_name, ".xlsx")))
  crop_residue_p_return_data <- read_excel(file.path(folders$crop_residue_p_return, paste0(file_name, ".xlsx")))
  crop_p_removal_data <- read_excel(file.path(folders$crop_p_removal_proportion, paste0(file_name, ".xlsx")))
  runoff_loss_coefficient_data <- read_excel(file.path(folders$runoff_loss_coefficient, paste0(file_name, ".xlsx")))
  
  # 合并数据
  combined_data <- data.frame(
    YEAR = crop_area_data$YEAR,
    Total_Area = crop_area_data$Total_Area,
    `Atmospheric Deposition` = atmospheric_data$Atmospheric_Deposition,
    `Weathering P` = weathering_data$Weathering,
    `SewageP_agriculture` = sew_agriculture_data$Sew_agriculture,
    `Inorganic fertilizer P` = fertilizer_p_data$P_CONSUMPTION,
    `Manure P recovery` = rowSums(
      cbind(
        current_coefficient * livestock_manure_p_recovery_data$Sum, # 6livestock放牧的比例去了cropland
        confined_manure_p_recovery_data$Sum,
        current_coefficient * nonconfined_manure_p_recovery_data$Sum # 14livestock放牧的比例去了cropland
      ), na.rm = TRUE
    ),
    `Residue P return` = crop_residue_p_return_data$Total,
    `Crop P removal` = crop_p_removal_data$Total_P_removal,
    `P loss coefficient` = runoff_loss_coefficient_data$Result,
    check.names = FALSE
  )
  
  # 生成输出文件路径
  output_file_path <- file.path(output_dir, paste0(file_name, ".xlsx"))
  
  # 保存结果到新的Excel文件
  write.xlsx(combined_data, output_file_path)
}

cat("处理完成，结果已保存到：", output_dir, "\n")



#############################################################################################
#################################### Pastureland P balance ##################################
#############################################################################################

# 加载必要的包
library(dplyr)
library(readxl)
library(openxlsx)
library(ggplot2)
library(tidyr)
library(rstudioapi)

# 清空环境
rm(list = ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义文件夹路径
folders <- list(
  pastureland_area = "Initial data/Pastureland area",
  runoff_loss_coefficient = "Initial data/Runoff loss coefficient pastureland",
  livestock_grazingp_14 = "P cycling/14 livestock grazing P",
  livestock_grazingp_6 = "P cycling/6 livestock grazing P",  
  atmospheric_deposition = "P cycling/Atmospheric deposition - pastureland",
  weathering = "P cycling/Weathering - pastureland",
  fertilizer_p = "P cycling/Fertilizer P pastureland",
  livestock_manure_onpastureland_14 = "P cycling/14 livestock manure P left on pastureland",
  livestock_manure_onpastureland_6 = "P cycling/6 livestock manure P left on pastureland",
  livestock_manure_recovery_pastureland_14 = "P cycling/14 livestock nonconfined manure P recovery",
  livestock_manure_recovery_pastureland_6 = "P cycling/6 livestock manure P recovery"
)

output_dir <- "P cycling/P balance pastureland"
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 定义每个州的 coefficient_to_pastureland 值
coefficient_to_pastureland <- list(
  "ALABAMA" = 0.2,
  "ALASKA" = 0.8,
  "ARIZONA" = 1,
  "ARKANSAS" = 0,
  "CALIFORNIA" = 0.2,
  "COLORADO" = 0,
  "CONNECTICUT" = 0,
  "DELAWARE" = 0,
  "FLORIDA" = 0,
  "GEORGIA" = 0,
  "HAWAII" = 0.8,
  "IDAHO" = 0,
  "ILLINOIS" = 0,
  "INDIANA" = 0,
  "IOWA" = 0,
  "KANSAS" = 0,
  "KENTUCKY" = 0,
  "LOUISIANA" = 0,
  "MAINE" = 0,
  "MARYLAND" = 0,
  "MASSACHUSETTS" = 0.2,
  "MICHIGAN" = 0,
  "MINNESOTA" = 0,
  "MISSISSIPPI" = 0,
  "MISSOURI" = 0,
  "MONTANA" = 0,
  "NEBRASKA" = 0,
  "NEVADA" = 0,
  "NEW HAMPSHIRE" = 0,
  "NEW JERSEY" = 0,
  "NEW MEXICO" = 0,
  "NEW YORK" = 0,
  "NORTH CAROLINA" = 0.3,
  "NORTH DAKOTA" = 0,
  "OHIO" = 0,
  "OKLAHOMA" = 0,
  "OREGON" = 0,
  "PENNSYLVANIA" = 0,
  "RHODE ISLAND" = 0,
  "SOUTH CAROLINA" = 0,
  "SOUTH DAKOTA" = 0,
  "TENNESSEE" = 0,
  "TEXAS" = 0.3,
  "UTAH" = 0.1,
  "VERMONT" = 0,
  "VIRGINIA" = 0,
  "WASHINGTON" = 0,
  "WEST VIRGINIA" = 0,
  "WISCONSIN" = 0,
  "WYOMING" = 0.5
)

# 获取pastureland area文件夹下的所有Excel文件
pastureland_area_files <- list.files(folders$pastureland_area, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)

# 处理每个文件
for (pastureland_area_file in pastureland_area_files) {
  # 获取文件名（去掉路径和扩展名）
  file_name <- tools::file_path_sans_ext(basename(pastureland_area_file))
  
  # 获取当前州的coefficient_to_pastureland值
  current_coefficient <- coefficient_to_pastureland[[toupper(file_name)]]
  
  # 读取所有相关文件
  pastureland_area_data <- read_excel(pastureland_area_file)
  atmospheric_data <- read_excel(file.path(folders$atmospheric_deposition, paste0(file_name, ".xlsx")))
  weathering_data <- read_excel(file.path(folders$weathering, paste0(file_name, ".xlsx")))
  livestock_grazingp_14_data <- read_excel(file.path(folders$livestock_grazingp_14, paste0(file_name, ".xlsx")))
  livestock_grazingp_6_data <- read_excel(file.path(folders$livestock_grazingp_6, paste0(file_name, ".xlsx")))
  fertilizer_p_data <- read_excel(file.path(folders$fertilizer_p, paste0(file_name, ".xlsx")))
  livestock_manure_onpastureland_14_data <- read_excel(file.path(folders$livestock_manure_onpastureland_14, paste0(file_name, ".xlsx")))
  livestock_manure_onpastureland_6_data <- read_excel(file.path(folders$livestock_manure_onpastureland_6, paste0(file_name, ".xlsx")))
  livestock_manure_recovery_pastureland_14_data <- read_excel(file.path(folders$livestock_manure_recovery_pastureland_14, paste0(file_name, ".xlsx")))
  livestock_manure_recovery_pastureland_6_data <- read_excel(file.path(folders$livestock_manure_recovery_pastureland_6, paste0(file_name, ".xlsx")))
  runoff_loss_coefficient_data <- read_excel(file.path(folders$runoff_loss_coefficient, paste0(file_name, ".xlsx")))
  
  # 合并数据
  combined_data <- data.frame(
    YEAR = pastureland_area_data$YEAR,
    Total_Area = pastureland_area_data$Total_Area,
    `Atmospheric Deposition` = atmospheric_data$Atmospheric_Deposition,
    `Weathering P` = weathering_data$Weathering,
    `Inorganic fertilizer P` = fertilizer_p_data$P_CONSUMPTION,
    `Manure left on pastureland` = rowSums(
      cbind(
        livestock_manure_onpastureland_14_data$Sum,
        livestock_manure_onpastureland_6_data$Sum
      ), na.rm = TRUE
    ),
    `Manure to pastureland` = rowSums(
      cbind(
        current_coefficient * livestock_manure_recovery_pastureland_14_data$Sum, # 14livestock放牧的比例去了pastureland
        current_coefficient * livestock_manure_recovery_pastureland_6_data$Sum # 6livestock放牧的比例去了pastureland
      ), na.rm = TRUE
    ),
    `Livestock P grazing` = rowSums(
      cbind(
        livestock_grazingp_14_data$Sum,
        livestock_grazingp_6_data$Sum
      ), na.rm = TRUE
    ),
    `P loss coefficient` = runoff_loss_coefficient_data$Result,
    check.names = FALSE
  )
  
  # 生成输出文件路径
  output_file_path <- file.path(output_dir, paste0(file_name, ".xlsx"))
  
  # 保存结果到新的Excel文件
  write.xlsx(combined_data, output_file_path)
}

cat("处理完成，结果已保存到：", output_dir, "\n")
