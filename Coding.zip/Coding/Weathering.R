# 1 kg⋅ha−1⋅yr−1 for weathering P for agricultural land 

# 加载必要的库
library(readxl)
library(openxlsx)
library(dplyr)
library(rstudioapi)

##########################################################################################
#################################### Weathering cropland P ###############################
##########################################################################################

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义输入和输出文件夹路径
input_dir <- "Initial data/Crop area"
output_dir <- "P cycling/Weathering - cropland"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 列出输入目录中的所有Excel文件
crop_files <- list.files(input_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 初始化一个列表来存储警告信息
warnings_list <- list()

# 处理每个Excel文件
for (crop_file in crop_files) {
  # 尝试捕获每个循环中的警告信息
  warning_state <- tryCatch({
    # 读取Excel文件
    data <- read_excel(crop_file)
    
    # 选择"YEAR"列和处理后的"Weathering"列
    processed_data <- data %>%
      select(YEAR, Total_Area) %>%
      mutate(Weathering = Total_Area / 1000) %>%
      select(YEAR, Weathering)
    
    # 获取文件名
    file_name <- basename(crop_file)
    
    # 定义输出文件路径
    output_file_path <- file.path(output_dir, file_name)
    
    # 将处理后的数据保存为新的Excel文件
    write.xlsx(processed_data, file = output_file_path, rowNames = FALSE)
    
    NULL  # 如果没有警告，返回NULL
  }, warning = function(w) {
    # 如果有警告，将其添加到警告列表中
    return(w)
  })
  
  # 将当前文件的警告信息添加到警告列表中
  if (!is.null(warning_state)) {
    warnings_list[[crop_file]] <- warning_state
  }
}

# 打印所有的警告信息
if (length(warnings_list) > 0) {
  print("警告信息：")
  print(warnings_list)
} else {
  print("没有警告信息。")
}

print("数据已成功写入新的文件夹。")

##########################################################################################
################################## Weathering pastureland P ##############################
##########################################################################################

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义输入和输出文件夹路径
input_dir <- "Initial data/Pastureland area"
output_dir <- "P cycling/Weathering - pastureland"

# 检查并创建输出目录（如果不存在）
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 列出输入目录中的所有Excel文件
crop_files <- list.files(input_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 初始化一个列表来存储警告信息
warnings_list <- list()

# 处理每个Excel文件
for (crop_file in crop_files) {
  # 尝试捕获每个循环中的警告信息
  warning_state <- tryCatch({
    # 读取Excel文件
    data <- read_excel(crop_file)
    
    # 选择"YEAR"列和处理后的"Weathering"列
    processed_data <- data %>%
      select(YEAR, Total_Area) %>%
      mutate(Weathering = Total_Area / 1000) %>%
      select(YEAR, Weathering)
    
    # 获取文件名
    file_name <- basename(crop_file)
    
    # 定义输出文件路径
    output_file_path <- file.path(output_dir, file_name)
    
    # 将处理后的数据保存为新的Excel文件
    write.xlsx(processed_data, file = output_file_path, rowNames = FALSE)
    
    NULL  # 如果没有警告，返回NULL
  }, warning = function(w) {
    # 如果有警告，将其添加到警告列表中
    return(w)
  })
  
  # 将当前文件的警告信息添加到警告列表中
  if (!is.null(warning_state)) {
    warnings_list[[crop_file]] <- warning_state
  }
}

# 打印所有的警告信息
if (length(warnings_list) > 0) {
  print("警告信息：")
  print(warnings_list)
} else {
  print("没有警告信息。")
}

print("数据已成功写入新的文件夹。")
