# 初始默认 P fertilizer 90%（cropland including hay）10%（pastureland）

# 加载必要的库
library(readxl)
library(openxlsx)
library(dplyr)
library(rstudioapi)

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义Excel文件的路径
file_path <- "Initial data/Preprocess/Fertilizer application/Fertilizer.xlsx"

# 读取Excel文件的数据
data <- read_excel(file_path)

# 获取所有独特的州名
states <- unique(data$LOCATION)

# 定义文件路径的目录
file_direction_cropland <- "P cycling/Fertilizer P cropland"
file_direction_pastureland <- "P cycling/Fertilizer P pastureland"

# 检查并创建目录（如果不存在）
if (!dir.exists(file_direction_cropland)) {
  dir.create(file_direction_cropland, recursive = TRUE)
}
if (!dir.exists(file_direction_pastureland)) {
  dir.create(file_direction_pastureland, recursive = TRUE)
}

# 定义每个州的 coefficient_to_cropland 值
coefficient_to_cropland <- list(
  "ALABAMA" = 0.7,
  "ALASKA" = 0.9,
  "ARIZONA" = 0.9,
  "ARKANSAS" = 1.1,
  "CALIFORNIA" = 0.9,
  "COLORADO" = 1.1,
  "CONNECTICUT" = 1.1,
  "DELAWARE" = 1.1,
  "FLORIDA" = 0.8,
  "GEORGIA" = 0.9,
  "HAWAII" = 0.5,
  "IDAHO" = 1.1,
  "ILLINOIS" = 1,
  "INDIANA" = 1.1,
  "IOWA" = 1,
  "KANSAS" = 1.1,
  "KENTUCKY" = 0.9,
  "LOUISIANA" = 0.9,
  "MAINE" = 0.9,
  "MARYLAND" = 1,
  "MASSACHUSETTS" = 0.7,
  "MICHIGAN" = 1.1,
  "MINNESOTA" = 1.1,
  "MISSISSIPPI" = 0.95,
  "MISSOURI" = 0.95,
  "MONTANA" = 0.95,
  "NEBRASKA" = 1.1,
  "NEVADA" = 0.9,
  "NEW HAMPSHIRE" = 1,
  "NEW JERSEY" = 0.9,
  "NEW MEXICO" = 0.9,
  "NEW YORK" = 1.1,
  "NORTH CAROLINA" = 0.9,
  "NORTH DAKOTA" = 0.95,
  "OHIO" = 0.95,
  "OKLAHOMA" = 0.9,
  "OREGON" = 0.9,
  "PENNSYLVANIA" = 1,
  "RHODE ISLAND" = 0.86,
  "SOUTH CAROLINA" = 0.9,
  "SOUTH DAKOTA" = 0.9,
  "TENNESSEE" = 0.9,
  "TEXAS" = 0.9,
  "UTAH" = 0.9,
  "VERMONT" = 0.9,
  "VIRGINIA" = 0.9,
  "WASHINGTON" = 0.9,
  "WEST VIRGINIA" = 0.9,
  "WISCONSIN" = 1,
  "WYOMING" = 0.9
)

# 定义每个州的 coefficient_to_pastureland 值
coefficient_to_pastureland <- list(
  "ALABAMA" = 0.15,
  "ALASKA" = 0.1,
  "ARIZONA" = 0.1,
  "ARKANSAS" = 0,
  "CALIFORNIA" = 0.1,
  "COLORADO" = 0.1,
  "CONNECTICUT" = 0.025,
  "DELAWARE" = 0,
  "FLORIDA" = 0.1,
  "GEORGIA" = 0.05,
  "HAWAII" = 0.1,
  "IDAHO" = 0.1,
  "ILLINOIS" = 0.005,
  "INDIANA" = 0.01,
  "IOWA" = 0.01,
  "KANSAS" = 0.05,
  "KENTUCKY" = 0.02,
  "LOUISIANA" = 0.03,
  "MAINE" = 0.02,
  "MARYLAND" = 0.02,
  "MASSACHUSETTS" = 0.02,
  "MICHIGAN" = 0.02,
  "MINNESOTA" = 0.02,
  "MISSISSIPPI" = 0.1,
  "MISSOURI" = 0.02,
  "MONTANA" = 0.1,
  "NEBRASKA" = 0.05,
  "NEVADA" = 0.1,
  "NEW HAMPSHIRE" = 0.1,
  "NEW JERSEY" = 0.02,
  "NEW MEXICO" = 0.1,
  "NEW YORK" = 0,
  "NORTH CAROLINA" = 0.02,
  "NORTH DAKOTA" = 0.02,
  "OHIO" = 0.02,
  "OKLAHOMA" = 0.1,
  "OREGON" = 0.1,
  "PENNSYLVANIA" = 0.1,
  "RHODE ISLAND" = 0.1,
  "SOUTH CAROLINA" = 0.1,
  "SOUTH DAKOTA" = 0.1,
  "TENNESSEE" = 0.1,
  "TEXAS" = 0.1,
  "UTAH" = 0.1,
  "VERMONT" = 0.1,
  "VIRGINIA" = 0.1,
  "WASHINGTON" = 0.1,
  "WEST VIRGINIA" = 0.1,
  "WISCONSIN" = 0.1,
  "WYOMING" = 0.1
)

# 初始化一个列表来存储警告信息
warnings_list <- list()

# 创建一个循环，通过州名过滤数据并保存到单独的Excel文件中
for (state in states) {
  # 获取当前州的coefficient_to_cropland值
  current_coefficient_cropland <- coefficient_to_cropland[[state]]
  current_coefficient_pastureland <- coefficient_to_pastureland[[state]]
  
  # 尝试捕获每个循环中的警告信息
  warning_state <- tryCatch({
    # 过滤出当前州的数据并进行计算和重命名
    state_data_cropland <- data %>%
      filter(LOCATION == state) %>%
      select(YEAR, P2O5_CONSUMPTION) %>%
      mutate(P_CONSUMPTION = current_coefficient_cropland * P2O5_CONSUMPTION / 2.29) %>% #P2O5肥×折算系数再分配到cropland
      select(YEAR, P_CONSUMPTION)
    
    state_data_pastureland <- data %>%
      filter(LOCATION == state) %>%
      select(YEAR, P2O5_CONSUMPTION) %>%
      mutate(P_CONSUMPTION = current_coefficient_pastureland * P2O5_CONSUMPTION / 2.29) %>% #P2O5肥×折算系数再分配到pastureland
      select(YEAR, P_CONSUMPTION)
    
    # 定义文件路径和文件名
    file_name_cropland <- paste0(file_direction_cropland, "/", state, ".xlsx")
    file_name_pastureland <- paste0(file_direction_pastureland, "/", state, ".xlsx")
    
    # 将数据保存为Excel文件
    write.xlsx(state_data_cropland, file = file_name_cropland, rowNames = FALSE)
    write.xlsx(state_data_pastureland, file = file_name_pastureland, rowNames = FALSE)
    
    NULL  # 如果没有警告，返回NULL
  }, warning = function(w) {
    # 如果有警告，将其添加到警告列表中
    return(w)
  })
  
  # 将当前州的警告信息添加到警告列表中
  if (!is.null(warning_state)) {
    warnings_list[[state]] <- warning_state
  }
}

# 打印所有的警告信息
if (length(warnings_list) > 0) {
  print("警告信息：")
  print(warnings_list)
} else {
  print("没有警告信息。")
}

print("数据已成功写入各个州的单独文件。")
