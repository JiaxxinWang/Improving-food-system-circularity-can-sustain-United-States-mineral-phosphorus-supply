# 加载必要的包
library(readxl)
library(dplyr)
library(tidyr)
library(writexl)

# 清空环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义导出文件的基础路径
output_folder <- "P cycling"

# 定义输入文件夹的路径
food_waste_folder <- "Initial data/Preprocess/Food waste"
meat_data_folder <- "Initial data/Preprocess/Meat data"
livestock_folder <- "Initial data/Livestock process"

# 定义文件路径
poultry_loss_file <- file.path(food_waste_folder, "poultry meat loss proportion.xlsx")
poultry_meat_file <- file.path(meat_data_folder, "poultry meat.xlsx")
chicken_meat_file <- file.path(meat_data_folder, "chicken meat.xlsx")

# 定义参数开关
scale_factor <- switch(getOption("global_vars")$monte_carlo_mode,
                       "1" = 0.9,  
                       "2" = 1,    
                       "3" = 1.1)  

weight_head <- list(
  "chicken" = 15.5,  # 总的chicken meat production/chicken head = 15.5
  "duck" = 15.5,     # 总的duck meat production/duck head = 15.5
  "turkey" = 15.5    # 总的turkey production/turkey head = 15.5
)

average_weight <- list(
  "chicken" = 2.5 * scale_factor,  # 每只平均重量
  "duck" = 3.5 * scale_factor,
  "turkey" = 13 * scale_factor
)

Annual_p_content_feed <- 5.76  # g per chicken

# 定义情景
scenarios <- c("Toward Sustainability", "Business As Usual", "Stratified Societies")

# 定义 "poultry meat loss proportion.xlsx" 中的表
loss_sheets <- c("As usual", "Half")

# 获取50个州的名称并转换为大写
states <- toupper(state.name)

# 遍历损失比例表
for (loss_sheet in loss_sheets) {
  # 添加前缀到文件夹名称
  folder_name <- file.path(output_folder, paste0("Poultry waste - ", loss_sheet))
  
  # 创建文件夹
  dir.create(folder_name, showWarnings = FALSE)
  
  summary_folder <- file.path(output_folder, paste0("Poultry waste - ", loss_sheet, "_summary"))
  dir.create(summary_folder, showWarnings = FALSE)
  
  # 读取家禽肉损失比例数据
  if (file.exists(poultry_loss_file)) {
    meat_loss_data <- read_excel(poultry_loss_file, sheet = loss_sheet) %>%
      filter(YEAR >= 1960 & YEAR <= 2050) %>%
      select(YEAR, Proportion)
  } else {
    stop(paste("文件不存在：", poultry_loss_file))
  }
  
  # 初始化列表以存储每个州每个情景下的 Total_Feed_P_Loss
  state_loss_data <- list()
  
  # 遍历情景
  for (scenario in scenarios) {
    # 读取当前情景的全国家禽肉生产数据
    poultry_meat <- read_excel(poultry_meat_file, sheet = scenario) %>%
      filter(YEAR >= 1960 & YEAR <= 2050) %>%
      select(YEAR, Poultry_Meat = Value)
    
    chicken_meat <- read_excel(chicken_meat_file, sheet = scenario) %>%
      filter(YEAR >= 1960 & YEAR <= 2050) %>%
      select(YEAR, Chicken_Meat = Value)
    
    # 计算全国鸭肉和火鸡肉的生产量
    meat_data <- poultry_meat %>%
      left_join(chicken_meat, by = "YEAR") %>%
      mutate(Duck_Turkey_Meat = Poultry_Meat - Chicken_Meat)
    
    # 转换单位为千克（kg）
    meat_data <- meat_data %>%
      mutate(
        Poultry_Meat = Poultry_Meat * 0.453592,
        Chicken_Meat = Chicken_Meat * 0.453592,
        Duck_Turkey_Meat = Duck_Turkey_Meat * 0.453592
      )
    
    # 读取各州的家禽头数数据
    state_livestock <- data.frame()
    
    for (state in states) {
      file_name <- file.path(livestock_folder, paste0(state, ".xlsx"))
      
      if (file.exists(file_name)) {
        state_data <- read_excel(file_name, sheet = "Sheet1") %>%
          filter(YEAR >= 1960 & YEAR <= 2050)
        
        # 检查并处理缺失的列
        if (!"Chicken broiler" %in% colnames(state_data)) {
          state_data$`Chicken broiler` <- 0
        }
        if (!"Duck" %in% colnames(state_data)) {
          state_data$Duck <- 0
        }
        if (!"Turkey" %in% colnames(state_data)) {
          state_data$Turkey <- 0
        }
        
        state_data <- state_data %>%
          select(YEAR, `Chicken broiler`, Duck, Turkey)
        
        state_data$State <- state
        state_livestock <- bind_rows(state_livestock, state_data)
      } else {
        warning(paste("文件", file_name, "不存在，已跳过。"))
      }
    }
    
    # 将NA替换为0
    state_livestock[is.na(state_livestock)] <- 0
    
    # 计算全国各类家禽的总头数
    total_headcounts <- state_livestock %>%
      group_by(YEAR) %>%
      summarise(
        Total_Chicken_Broiler = sum(`Chicken broiler`, na.rm = TRUE),
        Total_Duck = sum(Duck, na.rm = TRUE),
        Total_Turkey = sum(Turkey, na.rm = TRUE)
      )
    
    # 计算各州的家禽头数占全国的比例
    state_proportions <- state_livestock %>%
      left_join(total_headcounts, by = "YEAR") %>%
      mutate(
        Chicken_Broiler_Prop = ifelse(Total_Chicken_Broiler > 0, `Chicken broiler` / Total_Chicken_Broiler, 0),
        Duck_Prop = ifelse(Total_Duck > 0, Duck / Total_Duck, 0),
        Turkey_Prop = ifelse(Total_Turkey > 0, Turkey / Total_Turkey, 0)
      )
    
    state_proportions[is.na(state_proportions)] <- 0
    
    # 分配鸭肉和火鸡肉的生产量
    total_duck_turkey_heads <- total_headcounts %>%
      mutate(
        Total_Duck_Turkey = Total_Duck + Total_Turkey,
        Duck_Head_Prop = ifelse(Total_Duck_Turkey > 0, Total_Duck / Total_Duck_Turkey, 0),
        Turkey_Head_Prop = ifelse(Total_Duck_Turkey > 0, Total_Turkey / Total_Duck_Turkey, 0)
      )
    
    meat_data <- meat_data %>%
      left_join(total_duck_turkey_heads %>% select(YEAR, Duck_Head_Prop, Turkey_Head_Prop), by = "YEAR") %>%
      mutate(
        Duck_Meat = Duck_Turkey_Meat * Duck_Head_Prop,
        Turkey_Meat = Duck_Turkey_Meat * Turkey_Head_Prop
      )
    
    # 计算各州的家禽肉生产量
    state_meat_production <- state_proportions %>%
      left_join(meat_data %>% select(YEAR, Chicken_Meat, Duck_Meat, Turkey_Meat), by = "YEAR") %>%
      mutate(
        State_Chicken_Meat = Chicken_Meat * Chicken_Broiler_Prop,
        State_Duck_Meat = Duck_Meat * Duck_Prop,
        State_Turkey_Meat = Turkey_Meat * Turkey_Prop
      )
    
    # 计算各州的肉废弃量
    state_meat_waste <- state_meat_production %>%
      left_join(meat_loss_data, by = "YEAR") %>%
      mutate(
        Chicken_Meat_Waste = State_Chicken_Meat * Proportion,
        Duck_Meat_Waste = State_Duck_Meat * Proportion,
        Turkey_Meat_Waste = State_Turkey_Meat * Proportion
      )
    
    # 计算各州的头损失
    state_head_loss <- state_meat_waste %>%
      mutate(
        Chicken_Head_Loss = floor(Chicken_Meat_Waste / weight_head[["chicken"]]),
        Duck_Head_Loss = floor(Duck_Meat_Waste / weight_head[["duck"]]),
        Turkey_Head_Loss = floor(Turkey_Meat_Waste / weight_head[["turkey"]])
      )
    
    # 计算各州的饲料磷损失
    state_feed_p_loss <- state_head_loss %>%
      mutate(
        Chicken_Feed_P_Loss = Chicken_Head_Loss * average_weight[["chicken"]] * Annual_p_content_feed / 1000,  # 千克
        Duck_Feed_P_Loss = Duck_Head_Loss * average_weight[["duck"]] * Annual_p_content_feed / 1000,
        Turkey_Feed_P_Loss = Turkey_Head_Loss * average_weight[["turkey"]] * Annual_p_content_feed / 1000
      )
    
    # 计算总的饲料磷损失，并转换为吨
    state_feed_p_loss <- state_feed_p_loss %>%
      mutate(
        Total_Feed_P_Loss = (Chicken_Feed_P_Loss + Duck_Feed_P_Loss + Turkey_Feed_P_Loss) / 1000  # 转换为吨
      )
    
    # 选择需要的列，准备输出
    final_output <- state_feed_p_loss %>%
      select(
        YEAR, State,
        Chicken_Head_Loss, Duck_Head_Loss, Turkey_Head_Loss,
        Chicken_Feed_P_Loss, Duck_Feed_P_Loss, Turkey_Feed_P_Loss,
        Total_Feed_P_Loss
      )
    
    # 保存各州的结果
    # 创建情景文件夹
    scenario_folder <- file.path(folder_name, scenario)
    dir.create(scenario_folder, showWarnings = FALSE, recursive = TRUE)
    
    # 保存各州的数据
    state_list <- unique(final_output$State)
    
    for (state in state_list) {
      state_data <- final_output %>%
        filter(State == state)
      
      # 保存为以州名命名的Excel文件
      write_xlsx(state_data, file.path(scenario_folder, paste0(state, ".xlsx")))
      
      # 为汇总文件存储 Total_Feed_P_Loss
      if (!state %in% names(state_loss_data)) {
        state_loss_data[[state]] <- data.frame(YEAR = state_data$YEAR)
      }
      state_loss_data[[state]][[scenario]] <- state_data$Total_Feed_P_Loss
    }
  }
  
  # 在处理完所有情景后，保存汇总文件
  for (state in names(state_loss_data)) {
    state_summary_data <- state_loss_data[[state]]
    
    # 确保列的顺序正确
    state_summary_data <- state_summary_data %>%
      select(YEAR, `Toward Sustainability`, `Business As Usual`, `Stratified Societies`)
    
    # 重命名情景列以添加前缀 "TotalfeedP_loss_"
    colnames(state_summary_data)[2:4] <- paste0("TotalfeedP_loss_", colnames(state_summary_data)[2:4])
    
    # 保存为Excel文件
    write_xlsx(state_summary_data, file.path(summary_folder, paste0(state, ".xlsx")))
  }
  
  print(paste0("家禽饲料磷损失计算完成，损失表 '", loss_sheet, "' 的结果已保存至 '", folder_name, "' 和 '", summary_folder, "'。"))
}
