# 加载必要的包
library(dplyr)
library(readxl)
library(writexl)
library(tools)

######################################## Cropland ###################################
# 清空环境
rm(list = ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 设置初始值来计算Cover management factor
initial_c <- 1

# 定义每个州的 initial_b 值
initial_b <- list(
  "ALABAMA" = 0.02,
  "ALASKA" = 0.02,
  "ARIZONA" = 0.02,
  "ARKANSAS" = 0.02,
  "CALIFORNIA" = 0.02,
  "COLORADO" = 0.02,
  "CONNECTICUT" = 0.02,
  "DELAWARE" = 0.02,
  "FLORIDA" = 0.02,
  "GEORGIA" = 0.02,
  "HAWAII" = 0.02,
  "IDAHO" = 0.02,
  "ILLINOIS" = 0.02,
  "INDIANA" = 0.02,
  "IOWA" = 0.02,
  "KANSAS" = 0.02,
  "KENTUCKY" = 0.02,
  "LOUISIANA" = 0.02,
  "MAINE" = 0.02,
  "MARYLAND" = 0.02,
  "MASSACHUSETTS" = 0.02,
  "MICHIGAN" = 0.02,
  "MINNESOTA" = 0.02,
  "MISSISSIPPI" = 0.02,
  "MISSOURI" = 0.02,
  "MONTANA" = 0.02,
  "NEBRASKA" = 0.02,
  "NEVADA" = 0.02,
  "NEW HAMPSHIRE" = 0.02,
  "NEW JERSEY" = 0.02,
  "NEW MEXICO" = 0.02,
  "NEW YORK" = 0.02,
  "NORTH CAROLINA" = 0.02,
  "NORTH DAKOTA" = 0.02,
  "OHIO" = 0.02,
  "OKLAHOMA" = 0.02,
  "OREGON" = 0.02,
  "PENNSYLVANIA" = 0.02,
  "RHODE ISLAND" = 0.02,
  "SOUTH CAROLINA" = 0.02,
  "SOUTH DAKOTA" = 0.02,
  "TENNESSEE" = 0.02,
  "TEXAS" = 0.02,
  "UTAH" = 0.02,
  "VERMONT" = 0.02,
  "VIRGINIA" = 0.02,
  "WASHINGTON" = 0.02,
  "WEST VIRGINIA" = 0.02,
  "WISCONSIN" = 0.02,
  "WYOMING" = 0.02
)

# 定义输入和输出文件夹
runoff_loss_factor_dir <- "Preprocess/Runoff loss factor"
prcp_normalize_dir <- "PRCP - normalize"
output_dir <- "Runoff loss coefficient cropland"

# 确保输出目录存在
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 读取Cover management factor和Soil erosion factor文件
cover_management_factors <- read_excel(file.path(runoff_loss_factor_dir, "Cover management factor.xlsx"))
soil_erosion_factors <- read_excel(file.path(runoff_loss_factor_dir, "Soil erosion factor.xlsx"))

# 获取PRCP - normalize文件夹下的所有Excel文件
prcp_files <- list.files(prcp_normalize_dir, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)

# 处理每个文件
for (prcp_file in prcp_files) {
  # 读取PRCP文件中的数据
  prcp_data <- read_excel(prcp_file)
  
  # 获取州名（文件名去掉扩展名）
  state_name <- file_path_sans_ext(basename(prcp_file))
  
  # 检查州名是否存在于Cover management factor和Soil erosion factor文件中
  if (!(state_name %in% colnames(cover_management_factors)) || !(state_name %in% colnames(soil_erosion_factors))) {
    next
  }
  
  # 获取Normalized_Rainfall数据
  normalized_rainfall <- prcp_data$Normalized_Rainfall
  
  # 获取Cover management factor中的对应列
  cover_management_factor <- cover_management_factors[[state_name]]
  
  # 获取Soil erosion factor中的对应折算系数
  soil_erosion_factor <- soil_erosion_factors[[state_name]][1]
  
  # 检查数据长度是否一致
  if (length(normalized_rainfall) != length(cover_management_factor)) {
    next
  }
  
  # 计算结果
  result <- initial_b[[state_name]] * normalized_rainfall * (initial_c - cover_management_factor) * soil_erosion_factor
  
  # 创建结果数据框
  output_data <- data.frame(YEAR = prcp_data$YEAR, Result = result)
  
  # 生成输出文件路径
  output_file_path <- file.path(output_dir, paste0(state_name, ".xlsx"))
  
  # 保存结果到新的Excel文件
  write_xlsx(output_data, output_file_path)
}

cat("处理完成，结果已保存到：", output_dir, "\n")


######################################## Pastureland ###################################
# 清空环境
rm(list = ls())

# 定义每个州的 initial_b 值
initial_b <- list(
  "ALABAMA" = 0.01,
  "ALASKA" = 0.01,
  "ARIZONA" = 0.01,
  "ARKANSAS" = 0.01,
  "CALIFORNIA" = 0.01,
  "COLORADO" = 0.01,
  "CONNECTICUT" = 0.01,
  "DELAWARE" = 0.01,
  "FLORIDA" = 0.01,
  "GEORGIA" = 0.01,
  "HAWAII" = 0.01,
  "IDAHO" = 0.01,
  "ILLINOIS" = 0.01,
  "INDIANA" = 0.01,
  "IOWA" = 0.01,
  "KANSAS" = 0.01,
  "KENTUCKY" = 0.01,
  "LOUISIANA" = 0.01,
  "MAINE" = 0.01,
  "MARYLAND" = 0.01,
  "MASSACHUSETTS" = 0.01,
  "MICHIGAN" = 0.01,
  "MINNESOTA" = 0.01,
  "MISSISSIPPI" = 0.01,
  "MISSOURI" = 0.01,
  "MONTANA" = 0.01,
  "NEBRASKA" = 0.01,
  "NEVADA" = 0.01,
  "NEW HAMPSHIRE" = 0.01,
  "NEW JERSEY" = 0.01,
  "NEW MEXICO" = 0.01,
  "NEW YORK" = 0.01,
  "NORTH CAROLINA" = 0.01,
  "NORTH DAKOTA" = 0.01,
  "OHIO" = 0.01,
  "OKLAHOMA" = 0.01,
  "OREGON" = 0.01,
  "PENNSYLVANIA" = 0.01,
  "RHODE ISLAND" = 0.01,
  "SOUTH CAROLINA" = 0.01,
  "SOUTH DAKOTA" = 0.01,
  "TENNESSEE" = 0.01,
  "TEXAS" = 0.01,
  "UTAH" = 0.01,
  "VERMONT" = 0.01,
  "VIRGINIA" = 0.01,
  "WASHINGTON" = 0.01,
  "WEST VIRGINIA" = 0.01,
  "WISCONSIN" = 0.01,
  "WYOMING" = 0.01
)

# 定义输入和输出文件夹
runoff_loss_factor_dir <- "Preprocess/Runoff loss factor"
prcp_normalize_dir <- "PRCP - normalize"
output_dir <- "Runoff loss coefficient pastureland"

# 确保输出目录存在
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 读取Soil erosion factor文件
soil_erosion_factors <- read_excel(file.path(runoff_loss_factor_dir, "Soil erosion factor.xlsx"))

# 获取PRCP - normalize文件夹下的所有Excel文件
prcp_files <- list.files(prcp_normalize_dir, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)

# 处理每个文件
for (prcp_file in prcp_files) {
  # 读取PRCP文件中的数据
  prcp_data <- read_excel(prcp_file)
  
  # 获取州名（文件名去掉扩展名）
  state_name <- tools::file_path_sans_ext(basename(prcp_file))
  
  # 检查州名是否存在于Soil erosion factor文件中
  if (!(state_name %in% colnames(soil_erosion_factors))) {
    next
  }
  
  # 获取Normalized_Rainfall数据
  normalized_rainfall <- prcp_data$Normalized_Rainfall
  
  # 获取Soil erosion factor中的对应折算系数
  soil_erosion_factor <- soil_erosion_factors[[state_name]][1]
  
  # 计算结果
  result <- initial_b[[state_name]] * normalized_rainfall * soil_erosion_factor
  
  # 创建结果数据框
  output_data <- data.frame(YEAR = prcp_data$YEAR, Result = result)
  
  # 生成输出文件路径
  output_file_path <- file.path(output_dir, paste0(state_name, ".xlsx"))
  
  # 保存结果到新的Excel文件
  write_xlsx(output_data, output_file_path)
}

cat("处理完成，结果已保存到：", output_dir, "\n")
