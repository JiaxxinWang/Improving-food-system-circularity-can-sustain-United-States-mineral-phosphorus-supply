
#################################################################################################
##################################### livestock manure and grazing ##############################
#################################################################################################

# 加载必要的库
library(readxl)
library(dplyr)
library(openxlsx)

##################################################################################################
############################ 14 livestock manure P calculation with uncertainty ##################
##################################################################################################
# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义开关变量
scaling_factor <- switch(getOption("global_vars")$monte_carlo_mode,
                         "1" = 0.8,  # 当 scale_switch == 1 时
                         "2" = 1,    # 当 scale_switch == 2 时
                         "3" = 1.2)  # 当 scale_switch == 3 时
scale_data <- function(data, scaling_factor) {
  data_scaled <- data * scaling_factor
  return(data_scaled)
}

# 读取折算系数文件
animal_coef_file <- "Initial data/Preprocess/Manure coefficient/Animal unit coefficient.xlsx"
animal_coef_data <- read_excel(animal_coef_file)

p_coef_file <- "Initial data/Preprocess/Manure coefficient/Manure P excrete coefficient.xlsx"
p_coef_data <- read_excel(p_coef_file)
p_coef_data <- scale_data(p_coef_data, scaling_factor)  # 缩放函数计算

manure_per_animal_unit_file <- "Initial data/Preprocess/Manure coefficient/Manure per animal unit.xlsx"
manure_per_animal_unit_data <- read_excel(manure_per_animal_unit_file)
manure_per_animal_unit_data <- scale_data(manure_per_animal_unit_data, scaling_factor) # 缩放函数计算

p_loss_coef_file <- "Initial data/Preprocess/Manure coefficient/Manure P coefficient after loss.xlsx"
p_loss_coef_data <- read_excel(p_loss_coef_file)
p_loss_coef_data <- scale_data(p_loss_coef_data, scaling_factor) # 缩放函数计算

confinement_factor_file <- "Initial data/Preprocess/Manure coefficient/Confined factor.xlsx"
confinement_factor_data <- read_excel(confinement_factor_file)

recovery_factor_file <- "Initial data/Preprocess/Manure coefficient/Confined recovery factor.xlsx"
recovery_factor_data <- read_excel(recovery_factor_file)

nonconfined_factor_file <- "Initial data/Preprocess/Manure coefficient/Nonconfined factor.xlsx"
nonconfined_factor_data <- read_excel(nonconfined_factor_file)

# 获取 "Livestock process" 文件夹中的所有 Excel 文件
livestock_files <- list.files("Initial data/Livestock process", pattern = "*.xlsx", full.names = TRUE)

# 创建输出文件夹，如果不存在
output_folders <- list(
  "P cycling/14 livestock manure P total excrete",
  "P cycling/14 livestock confined manure P recovery",
  "P cycling/14 livestock manure P left on pastureland",
  "P cycling/14 livestock nonconfined manure P recovery",
  "P cycling/14 livestock manure P loss"
)

lapply(output_folders, function(folder) {
  if (!dir.exists(folder)) {
    dir.create(folder, recursive = TRUE)
  }
})

# 遍历每个 Excel 文件
for (file in livestock_files) {
  # 读取当前 Excel 文件
  livestock_data <- read_excel(file)
  state <- tools::file_path_sans_ext(basename(file))
  
  # 获取当前 Excel 文件的列名
  livestock_cols <- colnames(livestock_data)
  
  # 第1列是 YEAR，剩下的是 livestock 种类
  livestock_types <- livestock_cols[-1]
  
  # 筛选出与 state 匹配的行
  confinement_factor_row <- confinement_factor_data %>% filter(STATE == state)
  nonconfined_factor_row <- nonconfined_factor_data %>% filter(STATE == state)
  
  # 删除未找到匹配列的 confinement 和 nonconfined 数据
  confinement_factor_row <- confinement_factor_row[, c("STATE", intersect(livestock_types, colnames(confinement_factor_row)))]
  nonconfined_factor_row <- nonconfined_factor_row[, c("STATE", intersect(livestock_types, colnames(nonconfined_factor_row)))]
  
  # 第一步处理计算 14 livestock manure P total excrete
  processed_data <- livestock_data[, 1, drop = FALSE]  # 保留 YEAR 列
  for (livestock in livestock_types) {
    if (livestock %in% colnames(animal_coef_data) &&
        livestock %in% colnames(p_coef_data) &&
        livestock %in% colnames(manure_per_animal_unit_data)) {
      result <- (livestock_data[[livestock]] / animal_coef_data[[livestock]]) * 
        p_coef_data[[livestock]] * 
        manure_per_animal_unit_data[[livestock]]
      processed_data[[livestock]] <- result
    }
  }
  
  processed_data <- processed_data[, c("YEAR", intersect(livestock_types, colnames(processed_data)))]
  processed_data$Sum <- rowSums(processed_data[,-1], na.rm = TRUE)
  output_file_p_total <- file.path(output_folders[[1]], basename(file))
  write.xlsx(processed_data, file = output_file_p_total)
  
  # 第二部分处理计算 14 livestock confined manure P recovery to cropland
  confined_data <- livestock_data[, 1, drop = FALSE]  # 保留 YEAR 列
  for (livestock in livestock_types) {
    if (livestock %in% colnames(animal_coef_data) &&
        livestock %in% colnames(p_loss_coef_data) &&
        livestock %in% colnames(confinement_factor_row) &&
        livestock %in% colnames(recovery_factor_data) &&
        livestock %in% colnames(manure_per_animal_unit_data)) {
      result_confined <- (livestock_data[[livestock]] / animal_coef_data[[livestock]]) * 
        p_loss_coef_data[[livestock]] * 
        confinement_factor_row[[livestock]] * 
        recovery_factor_data[[livestock]] * 
        manure_per_animal_unit_data[[livestock]]
      confined_data[[livestock]] <- result_confined
    }
  }
  
  confined_data <- confined_data[, c("YEAR", intersect(livestock_types, colnames(confined_data)))]
  confined_data$Sum <- rowSums(confined_data[,-1], na.rm = TRUE)
  output_file_confined <- file.path(output_folders[[2]], basename(file))
  write.xlsx(confined_data, file = output_file_confined)
  
  # 第三部分处理计算 14 livestock manure P left on pastureland
  # 定义呆在pastureland放牧的时间
  Time_to_pastureland <- 5/12
  pastureland_data <- livestock_data[, 1, drop = FALSE]  # 保留 YEAR 列
  for (livestock in livestock_types) {
    if (livestock %in% colnames(animal_coef_data) &&
        livestock %in% colnames(p_coef_data) &&
        livestock %in% colnames(manure_per_animal_unit_data) &&
        livestock %in% colnames(nonconfined_factor_row)) {
      result_pastureland <- (livestock_data[[livestock]] / animal_coef_data[[livestock]]) * 
        p_coef_data[[livestock]] * 
        manure_per_animal_unit_data[[livestock]] * 
        nonconfined_factor_row[[livestock]] * Time_to_pastureland   #  时间在pastureland内放牧，manure on pastureland
      pastureland_data[[livestock]] <- result_pastureland
    }
  }
  
  pastureland_data <- pastureland_data[, c("YEAR", intersect(livestock_types, colnames(pastureland_data)))]
  pastureland_data$Sum <- rowSums(pastureland_data[,-1], na.rm = TRUE)
  output_file_pastureland <- file.path(output_folders[[3]], basename(file))
  write.xlsx(pastureland_data, file = output_file_pastureland)
  
  # 第四部分处理计算 14 livestock nonconfined manure P recovery to cropland
  nonconfined_recovery_data <- livestock_data[, 1, drop = FALSE]  # 保留 YEAR 列
  for (livestock in livestock_types) {
    if (livestock %in% colnames(animal_coef_data) &&
        livestock %in% colnames(p_loss_coef_data) &&
        livestock %in% colnames(manure_per_animal_unit_data) &&
        livestock %in% colnames(nonconfined_factor_row)) {
      result_nonconfined_recovery <- (livestock_data[[livestock]] / animal_coef_data[[livestock]]) * 
        p_loss_coef_data[[livestock]] * 
        manure_per_animal_unit_data[[livestock]] * 
        nonconfined_factor_row[[livestock]] * (1 - Time_to_pastureland)     #  剩下的时间在大棚内，manure全被收集起来使用
      nonconfined_recovery_data[[livestock]] <- result_nonconfined_recovery
    }
  }
  
  nonconfined_recovery_data <- nonconfined_recovery_data[, c("YEAR", intersect(livestock_types, colnames(nonconfined_recovery_data)))]
  nonconfined_recovery_data$Sum <- rowSums(nonconfined_recovery_data[,-1], na.rm = TRUE)
  output_file_nonconfined_recovery <- file.path(output_folders[[4]], basename(file))
  write.xlsx(nonconfined_recovery_data, file = output_file_nonconfined_recovery)
  
  # 第五部分计算 14 livestock manure P loss
  # 读取之前保存的结果
  total_excrete_data <- read_excel(output_file_p_total)  # 第一步处理计算的 14 livestock manure P total excrete
  confined_recovery_data <- read_excel(output_file_confined) # 第二部分处理计算的 14 livestock confined manure P recovery to cropland
  pastureland_data <- read_excel(output_file_pastureland) # 第三部分处理计算的 14 livestock manure P left on pastureland
  nonconfined_recovery_data <- read_excel(output_file_nonconfined_recovery) # 第四部分处理计算的 14 livestock nonconfined manure P recovery to cropland
  
  # 创建一个用于存储第五部分处理后数据的 data frame
  p_loss_data <- total_excrete_data[, 1, drop = FALSE]  # 保留 YEAR 列
  
  # 计算 P loss
  for (livestock in livestock_types) {
    if (livestock %in% colnames(total_excrete_data) &&
        livestock %in% colnames(confined_recovery_data) &&
        livestock %in% colnames(pastureland_data) &&
        livestock %in% colnames(nonconfined_recovery_data)) {
      p_loss_data[[livestock]] <- total_excrete_data[[livestock]] - 
        confined_recovery_data[[livestock]] - 
        pastureland_data[[livestock]] - 
        nonconfined_recovery_data[[livestock]]
    }
  }
  
  p_loss_data <- p_loss_data[, c("YEAR", intersect(livestock_types, colnames(p_loss_data)))]
  p_loss_data$Sum <- rowSums(p_loss_data[,-1], na.rm = TRUE)
  output_file_p_loss <- file.path(output_folders[[5]], basename(file))
  write.xlsx(p_loss_data, file = output_file_p_loss)
}



########################################################################################################
######################## 6 livestock total manure P and grazing with uncertainty #######################
########################################################################################################
# 清空环境
rm(list=ls())

# 获取 "Livestock process" 文件夹中的所有 Excel 文件
livestock_files <- list.files("Initial data/Livestock process", pattern = "*.xlsx", full.names = TRUE)

# 创建输出文件夹，如果不存在
output_folder_total <- "P cycling/6 livestock total manure P excrete"
if (!dir.exists(output_folder_total)) {
  dir.create(output_folder_total, recursive = TRUE)
}

output_folder_grazing <- "P cycling/6 livestock grazing P"
if (!dir.exists(output_folder_grazing)) {
  dir.create(output_folder_grazing, recursive = TRUE)
}

# 定义开关变量
scaling_factor <- switch(getOption("global_vars")$monte_carlo_mode,
                         "1" = 0.9, 
                         "2" = 1,   
                         "3" = 1.1) 

# 定义 grazing天数
grazing_time <- 150

# 定义 P content in grass
grass_Pcontent <- 0.002

# 遍历每个 Excel 文件
for (file in livestock_files) {
  # 读取当前 Excel 文件
  livestock_data <- read_excel(file)
  
  # 获取当前 Excel 文件的列名
  livestock_cols <- colnames(livestock_data)
  
  # 创建一个用于存储计算结果的 data frame
  processed_data_total <- livestock_data[, 1, drop = FALSE]  # 保留 YEAR 列
  processed_data_grazing <- livestock_data[, 1, drop = FALSE]  # 保留 YEAR 列
  
  # 计算指定列的数据 (total manure P)
  if ("Bison" %in% livestock_cols) {
    processed_data_total$Bison <- livestock_data$Bison * 35.74 * 0.18 / 1000 * scaling_factor
    processed_data_grazing$Bison <- livestock_data$Bison * 550 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor
  }
  if ("Sheep ewes" %in% livestock_cols) {
    processed_data_total$`Sheep ewes` <- livestock_data$`Sheep ewes` * 7 * 0.15 / 1000 * scaling_factor
    processed_data_grazing$`Sheep ewes` <- livestock_data$`Sheep ewes` * 97 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor
  }
  if ("Sheep lamb" %in% livestock_cols) {
    processed_data_total$`Sheep lamb` <- livestock_data$`Sheep lamb` * 5 * 0.15 / 1000 * scaling_factor
    processed_data_grazing$`Sheep lamb` <- livestock_data$`Sheep lamb` * 45 * 0.03 * grazing_time * grass_Pcontent / 1000 * scaling_factor
  }
  if ("Goat" %in% livestock_cols) {
    processed_data_total$Goat <- livestock_data$Goat * 7 * 0.15 / 1000 * scaling_factor
    processed_data_grazing$Goat <- livestock_data$Goat * 83 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor
  }
  if ("Elk" %in% livestock_cols) {
    processed_data_total$Elk <- livestock_data$Elk * 20 * 0.19 / 1000 * scaling_factor
    processed_data_grazing$Elk <- livestock_data$Elk * 275 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor
  }
  if ("Deer" %in% livestock_cols) {
    processed_data_total$Deer <- livestock_data$Deer * 9 * 0.19 / 1000 * scaling_factor
    processed_data_grazing$Deer <- livestock_data$Deer * 125 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor
  }
  
  # 计算 Sum 列
  processed_data_total$Sum <- rowSums(processed_data_total[, -1, drop = FALSE], na.rm = TRUE)
  processed_data_grazing$Sum <- rowSums(processed_data_grazing[, -1, drop = FALSE], na.rm = TRUE)
  
  # 确定输出文件的路径，保持与原文件相同的名字
  output_file_total <- file.path(output_folder_total, basename(file))
  output_file_grazing <- file.path(output_folder_grazing, basename(file))
  
  # 保存处理后的数据到新文件
  write.xlsx(processed_data_total, file = output_file_total)
  write.xlsx(processed_data_grazing, file = output_file_grazing)
}



#####################################################################################################
################################### 6 livestock manure P left on pastureland ########################
#####################################################################################################
# 清空环境
rm(list=ls())

# 获取 "P cycling/6 livestock total manure P" 文件夹中的所有 Excel 文件
total_manure_files <- list.files("P cycling/6 livestock total manure P excrete", pattern = "*.xlsx", full.names = TRUE)

# 创建输出文件夹，如果不存在
output_folder_pastureland <- "P cycling/6 livestock manure P left on pastureland"
if (!dir.exists(output_folder_pastureland)) {
  dir.create(output_folder_pastureland, recursive = TRUE)
}

output_folder_recovery <- "P cycling/6 livestock manure P recovery"
if (!dir.exists(output_folder_recovery)) {
  dir.create(output_folder_recovery, recursive = TRUE)
}

output_folder_p_loss <- "P cycling/6 livestock manure P loss"
if (!dir.exists(output_folder_p_loss)) {
  dir.create(output_folder_p_loss, recursive = TRUE)
}

# 定义呆在pastureland放牧的时间

Time_to_pastureland <- 5/12 # 因为假定 6 livestock grazing_time <- 150

# 遍历每个 Excel 文件
for (file in total_manure_files) {
  # 读取当前 Excel 文件
  total_manure_data <- read_excel(file)
  
  # 计算 manure left on pastureland 数据
  pastureland_data <- total_manure_data
  pastureland_data[,-1] <- total_manure_data[,-1] * Time_to_pastureland
  
  # 计算 manure recovery 数据
  recovery_data <- total_manure_data
  recovery_data[,-1] <- total_manure_data[,-1] * (1 - Time_to_pastureland)
  
  # 保存 pastureland 和 recovery 数据
  output_file_pastureland <- file.path(output_folder_pastureland, basename(file))
  output_file_recovery <- file.path(output_folder_recovery, basename(file))
  write.xlsx(pastureland_data, file = output_file_pastureland)
  write.xlsx(recovery_data, file = output_file_recovery)
  
  # 计算 P loss 数据
  p_loss_data <- total_manure_data
  p_loss_data[,-1] <- total_manure_data[,-1] - pastureland_data[,-1] - recovery_data[,-1]
  
  # 确定输出文件的路径，保持与原文件相同的名字
  output_file_p_loss <- file.path(output_folder_p_loss, basename(file))
  
  # 保存 P loss 数据到新文件
  write.xlsx(p_loss_data, file = output_file_p_loss)
}



######################################################################################################
################################ 14 livestock grazing P with uncertainty #############################
######################################################################################################
# 清空环境
rm(list=ls())

# 读取 Nonconfined factor 文件
nonconfined_factor_file <- "Initial data/Preprocess/Manure coefficient/Nonconfined factor.xlsx"
nonconfined_factor_data <- read_excel(nonconfined_factor_file)

# 获取 "Livestock process" 文件夹中的所有 Excel 文件
livestock_files <- list.files("Initial data/Livestock process", pattern = "*.xlsx", full.names = TRUE)

# 创建输出文件夹，如果不存在
output_folder_grazing <- "P cycling/14 livestock grazing P"
if (!dir.exists(output_folder_grazing)) {
  dir.create(output_folder_grazing, recursive = TRUE)
}

# 定义 grazing天数
grazing_time <- 150

# 定义 P content in grass
grass_Pcontent <- 0.002

# 定义开关变量
scaling_factor <- switch(getOption("global_vars")$monte_carlo_mode,
                         "1" = 0.9,  
                         "2" = 1,    
                         "3" = 1.1)  

# 遍历每个 Excel 文件
for (file in livestock_files) {
  # 读取当前 Excel 文件
  livestock_data <- read_excel(file)
  
  # 获取当前 Excel 文件的列名
  livestock_cols <- colnames(livestock_data)
  
  # 第1列是 YEAR，剩下的是 livestock 种类
  livestock_types <- livestock_cols[-1]
  
  # 筛选 Nonconfined factor 文件中的对应行
  state_name <- tools::file_path_sans_ext(basename(file))
  nonconfined_factors <- nonconfined_factor_data %>% filter(STATE == state_name)
  
  # 检查是否找到了对应的行
  if (nrow(nonconfined_factors) == 0) {
    warning(paste("未找到对应的非约束因子行:", state_name))
    next
  }
  
  # 初步处理计算 grazing P
  grazing_data <- livestock_data[, 1, drop = FALSE]  # 保留 YEAR 列
  for (livestock in livestock_types) {
    if (livestock == "Calves") {
      grazing_data[[livestock]] <- livestock_data[[livestock]] * 220 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor
    } else if (livestock == "Beef cows") {
      grazing_data[[livestock]] <- livestock_data[[livestock]] * 450 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor 
    } else if (livestock == "Milk cows") {
      grazing_data[[livestock]] <- livestock_data[[livestock]] * 450 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor 
    } else if (livestock == "Bulls") {
      grazing_data[[livestock]] <- livestock_data[[livestock]] * 600 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor 
    } else if (livestock %in% c("Heifers beef", "Steers", "Heifers milk")) {
      grazing_data[[livestock]] <- livestock_data[[livestock]] * 400 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor 
    } else if (livestock == "Heifers") {
      grazing_data[[livestock]] <- livestock_data[[livestock]] * 400 * 0.02 * grazing_time * grass_Pcontent / 1000 * scaling_factor
    } else {
      grazing_data[[livestock]] <- NA
    }
  }
  
  # 删除未匹配的列
  grazing_data <- grazing_data[, c("YEAR", intersect(livestock_types, colnames(grazing_data)))]
  
  # 应用 Nonconfined factors
  for (livestock in colnames(grazing_data)[-1]) {
    if (livestock %in% colnames(nonconfined_factors)) {
      grazing_data[[livestock]] <- grazing_data[[livestock]] * nonconfined_factors[[livestock]]
    } else {
      grazing_data[[livestock]] <- NULL  # 删除未匹配的列
    }
  }
  
  # 计算 SUM 列
  grazing_data$Sum <- rowSums(grazing_data[,-1], na.rm = TRUE)
  
  # 导出结果
  output_file_grazing <- file.path(output_folder_grazing, basename(file))
  write.xlsx(grazing_data, file = output_file_grazing)
}

print("所有文件已成功处理并保存。")





######################################################################################################
################################## 14 livestock manure P loss partition ##############################
######################################################################################################
# 加载所需的库
library(readxl)
library(dplyr)
library(openxlsx)

# 清空工作环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义文件路径
input_dir <- "P cycling/14 livestock manure P loss"

# 定义目标文件夹路径，如果不存在则创建
output_dirs <- list(
  cattlehog = "P cycling/14 livestock manure P loss cattlehog",
  chicken = "P cycling/14 livestock manure P loss chicken"
  #other = "P cycling/14 livestock manure P loss other"
)

for (dir in output_dirs) {
  if (!dir.exists(dir)) dir.create(dir, recursive = TRUE)
}

# 定义各个类别的列名
categories <- list(
  cattlehog = c("Beef cows", "Bison", "Bulls", "Calves", "Heifers beef", 
                "Heifers milk", "Heifers", "Hog breeding", "Hog slaughter", 
                "Milk cows", "Steers"),
  chicken = c("Chicken broiler", "Chicken excl broiler", "Duck", "Turkey")
  #other = c("Deer", "Elk", "Goat", "Sheep ewes", "Sheep lamb")
)

# 列出目录中的所有Excel文件
excel_files <- list.files(input_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 定义一个函数来处理并导出Excel
process_excel <- function(file, category, columns, output_dir, new_column_name) {
  # 读取数据
  df <- read_excel(file)
  
  # 保留 "YEAR" 列和需要的列
  selected_cols <- c("YEAR", intersect(columns, names(df)))
  df_selected <- df %>% select(any_of(selected_cols))
  
  # 求和并重命名列
  df_summarized <- df_selected %>%
    rowwise() %>%
    mutate(!!new_column_name := sum(c_across(-YEAR), na.rm = TRUE)) %>%
    ungroup() %>%
    select(YEAR, !!new_column_name)
  
  # 导出到新的目录
  output_file <- file.path(output_dir, basename(file))
  write.xlsx(df_summarized, output_file)
}

# 处理每个类别
for (file in excel_files) {
  process_excel(file, "cattlehog", categories$cattlehog, output_dirs$cattlehog, "Cattlehog manure P loss")
  process_excel(file, "chicken", categories$chicken, output_dirs$chicken, "Chicken manure P loss")
  #process_excel(file, "other", categories$other, output_dirs$other, "Other manure P loss")
}

print("所有文件处理完成并导出到相应的文件夹。")