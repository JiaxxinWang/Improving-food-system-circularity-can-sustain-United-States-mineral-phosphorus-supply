
################################################################################################
##################################### Livestock bone P production ##############################
################################################################################################

# 加载必要的包
library(readxl)
library(dplyr)
library(openxlsx)

# 清空环境
rm(list=ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义coefficients
# Average weight (kg)
weight_cows <- 450 # kg
weight_Bison <- 550
weight_Bulls <- 600
weight_Calves <- 220
weight_Chicken <- 2.5
weight_Duck <- 3.5
weight_Turkey <- 13
weight_Deer <- 125
weight_Elk <- 275
weight_Goat <- 83
weight_Heifers <- 400
weight_Hogbreed <- 275
weight_Hogslaug <- 130
weight_Sheepewes <- 97
weight_Sheeplamb <- 45

# Proportion of dry skeletal weight to live body weight
skeletal_weight_cattle <- 0.1
skeletal_weight_poultry <- 0.05
skeletal_weight_sheep <- 0.08
skeletal_weight_elk <- 0.09
skeletal_weight_deer <- 0.13
skeletal_weight_hog <- 0.07

# Proportion of ashes to skeleton
ash_proportion_cattle <- 0.65
ash_proportion_poultry <- 0.6
ash_proportion_sheep <- 0.6
ash_proportion_elk <- 0.6
ash_proportion_deer <- 0.6
ash_proportion_hog <- 0.63

P_bones <- 0.177 # P in bone ashes 17.7%

# 定义每个牲畜类型的计算系数区间（假设±20%的波动）
coefficients <- list(
  "Beef cows" = c(weight_cows * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_cows * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Bison" = c(weight_Bison * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_Bison * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Bulls" = c(weight_Bulls * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_Bulls * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Calves" = c(weight_Calves * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_Calves * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Chicken broiler" = c(weight_Chicken * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 0.8, weight_Chicken * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 1.2),
  "Chicken excl broiler" = c(weight_Chicken * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 0.8, weight_Chicken * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 1.2),
  "Duck" = c(weight_Duck * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 0.8, weight_Duck * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 1.2),
  "Turkey" = c(weight_Turkey * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 0.8, weight_Turkey * skeletal_weight_poultry * ash_proportion_poultry * P_bones / 1000 * 1.2),
  "Deer" = c(weight_Deer * skeletal_weight_deer * ash_proportion_deer * P_bones / 1000 * 0.8, weight_Deer * skeletal_weight_deer * ash_proportion_deer * P_bones / 1000 * 1.2),
  "Elk" = c(weight_Elk * skeletal_weight_elk * ash_proportion_elk * P_bones / 1000 * 0.8, weight_Elk * skeletal_weight_elk * ash_proportion_elk * P_bones / 1000 * 1.2),
  "Goat" = c(weight_Goat * skeletal_weight_sheep * ash_proportion_sheep * P_bones / 1000 * 0.8, weight_Goat * skeletal_weight_sheep * ash_proportion_sheep * P_bones / 1000 * 1.2),
  "Heifers beef" = c(weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Heifers milk" = c(weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Heifers" = c(weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Milk cows" = c(weight_cows * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_cows * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Steers" = c(weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 0.8, weight_Heifers * skeletal_weight_cattle * ash_proportion_cattle * P_bones / 1000 * 1.2),
  "Hog breeding" = c(weight_Hogbreed * skeletal_weight_hog * ash_proportion_hog * P_bones / 1000 * 0.8, weight_Hogbreed * skeletal_weight_hog * ash_proportion_hog * P_bones / 1000 * 1.2),
  "Hog slaughter" = c(weight_Hogslaug * skeletal_weight_hog * ash_proportion_hog * P_bones / 1000 * 0.8, weight_Hogslaug * skeletal_weight_hog * ash_proportion_hog * P_bones / 1000 * 1.2),
  "Sheep ewes" = c(weight_Sheepewes * skeletal_weight_sheep * ash_proportion_sheep * P_bones / 1000 * 0.8, weight_Sheepewes * skeletal_weight_sheep * ash_proportion_sheep * P_bones / 1000 * 1.2),
  "Sheep lamb" = c(weight_Sheeplamb * skeletal_weight_sheep * ash_proportion_sheep * P_bones / 1000 * 0.8, weight_Sheeplamb * skeletal_weight_sheep * ash_proportion_sheep * P_bones / 1000 * 1.2)
)

# 获取Livestock process目录中的所有Excel文件
input_directory <- "Initial data/Livestock slaughter process"
output_directory <- "P cycling/Livestock bone P production"
files <- list.files(input_directory, pattern = "*.xlsx", full.names = TRUE)

# 创建输出目录（如果不存在）
if (!dir.exists(output_directory)) {
  dir.create(output_directory, recursive = TRUE)
}

# 设置开关，控制蒙特卡洛模拟模式
# 定义一个函数来根据开关选择系数
get_coefficient <- function(coefficient_range, mode) {
  if (mode == 1) {
    # 5% 分位数
    return(coefficient_range[1] + 0.05 * (coefficient_range[2] - coefficient_range[1]))
  } else if (mode == 2) {
    # 均值
    return(mean(coefficient_range))
  } else if (mode == 3) {
    # 95% 分位数
    return(coefficient_range[1] + 0.95 * (coefficient_range[2] - coefficient_range[1]))
  }
}

# 处理每个Excel文件
for (file in files) {
  # 读取Excel文件
  data <- read_excel(file)
  
  # 检查哪些列名在系数列表中
  livestock_columns <- intersect(names(data), names(coefficients))
  
  # 如果数据列中没有匹配的livestock列，跳过这个文件
  if (length(livestock_columns) == 0) {
    next
  }
  
  # 计算每种livestock的P含量，并求和
  for (col in livestock_columns) {
    coefficient_range <- coefficients[[col]]
    coefficient <- get_coefficient(coefficient_range, getOption("global_vars")$monte_carlo_mode)
    data[[col]] <- data[[col]] * coefficient
  }
  
  # 计算SUM列
  data$SUM <- rowSums(data[livestock_columns], na.rm = TRUE)
  
  # 保存结果到新的Excel文件
  output_file <- file.path(output_directory, basename(file))
  write.xlsx(data, output_file, overwrite = TRUE)
}

print("All files have been processed and saved.")





################################################################################################
##################################### Livestock bone P partition ###############################
################################################################################################
# 加载所需的库
library(readxl)
library(dplyr)
library(openxlsx)

# 清空工作环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义文件路径
input_dir <- "P cycling/Livestock bone P production"

# 定义目标文件夹路径，如果不存在则创建
output_dirs <- list(
  cattlehog = "P cycling/Livestock bone P cattlehog",
  chicken = "P cycling/Livestock bone P chicken",
  other = "P cycling/Livestock bone P other"
)

for (dir in output_dirs) {
  if (!dir.exists(dir)) dir.create(dir, recursive = TRUE)
}

# 定义各个类别的列名
categories <- list(
  cattlehog = c("Beef cows", "Bison", "Bulls", "Calves", "Heifers beef", 
                "Heifers milk", "Heifers", "Hog breeding", "Hog slaughter", 
                "Milk cows", "Steers"),
  chicken = c("Chicken broiler", "Chicken excl broiler", "Duck", "Turkey"),
  other = c("Deer", "Elk", "Goat", "Sheep ewes", "Sheep lamb")
)

# 列出目录中的所有Excel文件
excel_files <- list.files(input_dir, pattern = "\\.xlsx$", full.names = TRUE)

# 定义一个函数来处理并导出Excel
process_excel <- function(file, category, columns, output_dir, new_column_name) {
  # 读取数据
  df <- read_excel(file)
  
  # 保留 "YEAR" 列和需要的列
  selected_cols <- c("YEAR", intersect(columns, names(df)))
  df_selected <- df %>% select(any_of(selected_cols))
  
  # 求和并重命名列
  df_summarized <- df_selected %>%
    rowwise() %>%
    mutate(!!new_column_name := sum(c_across(-YEAR), na.rm = TRUE)) %>%
    ungroup() %>%
    select(YEAR, !!new_column_name)
  
  # 导出到新的目录
  output_file <- file.path(output_dir, basename(file))
  write.xlsx(df_summarized, output_file)
}

# 处理每个类别
for (file in excel_files) {
  process_excel(file, "cattlehog", categories$cattlehog, output_dirs$cattlehog, "Cattlehog bone P")
  process_excel(file, "chicken", categories$chicken, output_dirs$chicken, "Chicken bone P")
  process_excel(file, "other", categories$other, output_dirs$other, "Other bone P")
}

print("所有文件处理完成并导出到相应的文件夹。")