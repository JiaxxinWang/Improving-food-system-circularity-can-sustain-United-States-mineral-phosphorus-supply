# 加载必要的库
library(readxl)
library(dplyr)
library(writexl)

# 清空环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 定义文件夹路径
input_folder <- "P cycling/Crop P removal proportion"

# 获取所有Excel文件的路径
excel_files <- list.files(input_folder, pattern = "*.xlsx", full.names = TRUE)

# 初始化空数据框来存储结果
result_data <- data.frame(YEAR = 1866:2050)

# 初始化列来存储总和
result_data$Total_P_removal <- 0
result_data$Hay_sum <- 0
result_data$Grain_sum <- 0

# 初始化列表来存储跳过的文件
skipped_files <- list()

# 遍历每个文件
for (file in excel_files) {
  # 读取数据
  data <- read_excel(file)
  
  # 检查是否包含 "Hay_sum" 和 "Grain_sum" 列
  if (!("Hay_sum" %in% colnames(data)) || !("Grain_sum" %in% colnames(data))) {
    skipped_files <- c(skipped_files, file)
    next  # 跳过没有 "Hay_sum" 或 "Grain_sum" 列的文件
  }
  
  # 计算每年的“Total_P_removal”、“Hay_sum”和“Grain_sum”的总和
  aggregated_data <- data %>%
    filter(YEAR >= 1866 & YEAR <= 2050) %>%
    group_by(YEAR) %>%
    summarize(
      Total_P_removal = sum(Total_P_removal, na.rm = TRUE),
      Hay_sum = sum(Hay_sum, na.rm = TRUE),
      Grain_sum = sum(Grain_sum, na.rm = TRUE)
    )
  
  # 合并到结果数据框
  result_data <- result_data %>%
    left_join(aggregated_data, by = "YEAR", suffix = c("", ".new")) %>%
    mutate(
      Total_P_removal = Total_P_removal + coalesce(Total_P_removal.new, 0),
      Hay_sum = Hay_sum + coalesce(Hay_sum.new, 0),
      Grain_sum = Grain_sum + coalesce(Grain_sum.new, 0)
    ) %>%
    select(-ends_with(".new"))
}

# 输出跳过的文件
if (length(skipped_files) > 0) {
  message("跳过以下没有 'Hay_sum' 或 'Grain_sum' 列的文件：")
  print(skipped_files)
} else {
  message("所有文件均包含 'Hay_sum' 和 'Grain_sum' 列。")
}

# 查看结果
#print(result_data)

# 可选：保存结果到新的Excel文件
write_xlsx(result_data, "P cycling/Crop_P_removal_summary.xlsx")










# 清空环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

library(readxl)
library(writexl)
library(dplyr)

# Define the folder and output file paths
input_folder <- "P cycling/Crop residue P return"
output_file <- "P cycling/National crop residue P return.xlsx"

# Get the list of all Excel files in the input folder
excel_files <- list.files(input_folder, pattern = "\\.xlsx$", full.names = TRUE)

# Initialize an empty data frame to store the results
final_results <- data.frame()

# Loop through each Excel file
for (file in excel_files) {
  # Read the Excel file
  data <- read_excel(file)
  
  # Check if the required columns exist
  required_columns <- c("YEAR", "Total", "Corn_grain_P_removal", "Corn_silage_P_removal", 
                        "Soybeans_P_removal", "Winter_wheat_P_removal", 
                        "Spring_wheat_P_removal", "Durum_wheat_P_removal")
  
  available_columns <- intersect(required_columns, colnames(data))
  
  if ("YEAR" %in% available_columns) {
    # Group by YEAR and sum up the available columns
    summarized_data <- data %>%
      select(all_of(c("YEAR", available_columns))) %>%
      group_by(YEAR) %>%
      summarize(across(everything(), sum, na.rm = TRUE), .groups = "drop")
    
    # Append the results to the final data frame
    final_results <- bind_rows(final_results, summarized_data)
  }
}

# Summarize the results across all files by YEAR
final_results <- final_results %>%
  group_by(YEAR) %>%
  summarize(across(everything(), sum, na.rm = TRUE), .groups = "drop")

# Write the final results to an Excel file
write_xlsx(final_results, output_file)

cat("数据已成功处理并保存到:", output_file, "\n")



# 清空环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

library(readxl)
library(writexl)
library(dplyr)

# Define the folder and output file paths
input_folder <- "P cycling/Crop residue P removal"
output_file <- "P cycling/National total crop residue P removal.xlsx"

# Get the list of all Excel files in the input folder
excel_files <- list.files(input_folder, pattern = "\\.xlsx$", full.names = TRUE)

# Initialize an empty data frame to store the results
final_results <- data.frame()

# Loop through each Excel file
for (file in excel_files) {
  # Read the Excel file
  data <- read_excel(file)
  
  # Check if the required columns exist
  required_columns <- c("YEAR", "Total_P_removal", "Corn_grain_P_removal", "Corn_silage_P_removal", 
                        "Soybeans_P_removal", "Winter_wheat_P_removal", 
                        "Spring_wheat_P_removal", "Durum_wheat_P_removal")
  
  available_columns <- intersect(required_columns, colnames(data))
  
  if ("YEAR" %in% available_columns) {
    # Group by YEAR and sum up the available columns
    summarized_data <- data %>%
      select(all_of(c("YEAR", available_columns))) %>%
      group_by(YEAR) %>%
      summarize(across(everything(), sum, na.rm = TRUE), .groups = "drop")
    
    # Append the results to the final data frame
    final_results <- bind_rows(final_results, summarized_data)
  }
}

# Summarize the results across all files by YEAR
final_results <- final_results %>%
  group_by(YEAR) %>%
  summarize(across(everything(), sum, na.rm = TRUE), .groups = "drop")

# Write the final results to an Excel file
write_xlsx(final_results, output_file)

cat("数据已成功处理并保存到:", output_file, "\n")





# 清空环境
rm(list = ls())

# 设置工作目录为当前脚本所在目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

library(readxl)
library(writexl)
library(dplyr)

# Define the folder and output file paths
input_folder <- "P cycling/Crop residue P return"
output_file <- "P cycling/National crop residue P return.xlsx"
final_output_file <- "P cycling/National crop residue waste.xlsx"

# Get the list of all Excel files in the input folder
excel_files <- list.files(input_folder, pattern = "\\.xlsx$", full.names = TRUE)

# Initialize an empty data frame to store the results
final_results <- data.frame()

# Loop through each Excel file
for (file in excel_files) {
  # Read the Excel file
  data <- read_excel(file)
  
  # Check if the required columns exist
  required_columns <- c("YEAR", "Total", "Corn_grain_P_removal", "Corn_silage_P_removal", 
                        "Soybeans_P_removal", "Winter_wheat_P_removal", 
                        "Spring_wheat_P_removal", "Durum_wheat_P_removal")
  
  available_columns <- intersect(required_columns, colnames(data))
  
  if ("YEAR" %in% available_columns) {
    # Group by YEAR and sum up the available columns
    summarized_data <- data %>%
      select(all_of(c("YEAR", available_columns))) %>%
      group_by(YEAR) %>%
      summarize(across(everything(), sum, na.rm = TRUE), .groups = "drop")
    
    # Append the results to the final data frame
    final_results <- bind_rows(final_results, summarized_data)
  }
}

# Summarize the results across all files by YEAR
final_results <- final_results %>%
  group_by(YEAR) %>%
  summarize(across(everything(), sum, na.rm = TRUE), .groups = "drop")

# Write the final results to an Excel file
write_xlsx(final_results, output_file)

# Read the National total crop residue P removal file
national_total_file <- "P cycling/National total crop residue P removal.xlsx"
national_total_data <- read_excel(national_total_file)

# Read the National crop residue P return file
national_return_data <- read_excel(output_file)

# Merge the two datasets on YEAR
merged_data <- merge(national_total_data, national_return_data, by = "YEAR", all.x = TRUE)

# Perform the subtraction calculations
result_data <- merged_data %>%
  mutate(
    Total_P_waste = Total_P_removal - Total,
    Corn_grain_P_waste = Corn_grain_P_removal.x - Corn_grain_P_removal.y,
    Corn_silage_P_waste = Corn_silage_P_removal.x - Corn_silage_P_removal.y,
    Soybeans_P_waste = Soybeans_P_removal.x - Soybeans_P_removal.y,
    Winter_wheat_P_waste = Winter_wheat_P_removal.x - Winter_wheat_P_removal.y,
    Spring_wheat_P_waste = Spring_wheat_P_removal.x - Spring_wheat_P_removal.y,
    Durum_wheat_P_waste = Durum_wheat_P_removal.x - Durum_wheat_P_removal.y
  ) %>%
  select(YEAR, Total_P_waste, Corn_grain_P_waste, Corn_silage_P_waste, Soybeans_P_waste, 
         Winter_wheat_P_waste, Spring_wheat_P_waste, Durum_wheat_P_waste)

# Write the final results to an Excel file
write_xlsx(result_data, final_output_file)

cat("数据已成功处理并保存到:", final_output_file, "\n")
