

# 在PRCP process里面读取不同的precipitation气候scenario

#################################################################################################
########################################### PRCP process ########################################
#################################################################################################
# 将precipitation和snowfall合并

# 加载所需的包
library(dplyr)
library(readxl)
library(openxlsx)

# 清空环境
rm(list=ls())

# 设置工作目录为当前文件所在的目录
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# 设置文件路径
precipitation_file <- "Preprocess/aggregated_data_precipitation.xlsx"
snow_file <- "Preprocess/all_aggregated_data_snow.xlsx"
output_folder <- "PRCP process"

# 创建输出文件夹（如果不存在）
if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

# 读取precipitation Excel文件
precipitation_data <- read_excel(precipitation_file, sheet = 'Model Mean RCP4.5') # Model Mean RCP4.5; #Model High RCP8.5

# 读取snow Excel文件
snow_data <- read_excel(snow_file, sheet = 1)

# 确保两者的DATE列一致
if (!all(precipitation_data$DATE == snow_data$DATE)) {
  stop("The DATE columns in the two files do not match.")
}

# 获取所有列名（去掉DATE列）
columns <- setdiff(names(precipitation_data), "DATE")

# 循环处理每个州的列
for (column in columns) {
  if (column %in% names(snow_data)) {
    # 计算PRCP和SNOW的和
    sum_data <- data.frame(
      YEAR = precipitation_data$DATE,
      SUM = precipitation_data[[column]] + snow_data[[column]]
    )
    
    # 生成输出文件路径
    output_file <- file.path(output_folder, paste0(column, ".xlsx"))
    
    # 保存到Excel文件
    write.xlsx(sum_data, output_file, rowNames = FALSE)  # 修改此行
    
    cat("Saved:", output_file, "\n")
  }
}

#################################################################################################
########################################### PRCP normalize ######################################
#################################################################################################
# 将合并的precipitation和snowfall之和 做normalize rescaling处理到0-1上面

# 加载所需的包
library(writexl)

# 清空环境
rm(list=ls())

# 定义输入输出文件夹
input_dir <- "PRCP process"
output_dir <- "PRCP - normalize"

# 确保输出目录存在
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 获取输入目录下的所有Excel文件
excel_files <- list.files(input_dir, pattern = "\\.xlsx$|\\.xls$", full.names = TRUE)

# 处理每个文件
for (file_path in excel_files) {
  # 读取Excel文件中的数据
  observation <- read_excel(file_path, sheet = "Sheet 1")
  
  # 假设降雨数据在第二列“SUM”列
  rainfall <- observation$SUM
  
  # 计算最大值和最小值
  max_value <- max(rainfall, na.rm = TRUE)
  min_value <- min(rainfall, na.rm = TRUE)
  
  # 最大最小归一化处理
  observation <- observation %>%
    mutate(Normalized_Rainfall = (SUM - min_value) / (max_value - min_value))
  
  # 找到归一化后的最大值和次大值、最小值和次小值
  max_normalized <- max(observation$Normalized_Rainfall, na.rm = TRUE)
  min_normalized <- min(observation$Normalized_Rainfall, na.rm = TRUE)
  second_max_normalized <- max(observation$Normalized_Rainfall[observation$Normalized_Rainfall < max_normalized], na.rm = TRUE)
  second_min_normalized <- min(observation$Normalized_Rainfall[observation$Normalized_Rainfall > min_normalized], na.rm = TRUE)
  
  # 替换最大值和最小值
  observation <- observation %>%
    mutate(Normalized_Rainfall = case_when(
      Normalized_Rainfall == max_normalized ~ second_max_normalized,
      Normalized_Rainfall == min_normalized ~ second_min_normalized,
      TRUE ~ Normalized_Rainfall
    ))
  
  # 生成输出文件路径
  output_file_path <- file.path(output_dir, basename(file_path))
  
  # 保存结果到新的Excel文件
  write_xlsx(observation, output_file_path)
}

cat("Rescale处理完成，结果已保存到：", output_dir, "\n")
